import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Route, Switch } from "wouter";
import { AnimatePresence, motion } from "framer-motion";
import { useLocation } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Bazaar from "./pages/Bazaar";
import Dashboard from "./pages/Dashboard";
import Leaderboard from "./pages/Leaderboard";
import MyCards from "./pages/MyCards";
import NotFound from "./pages/NotFound";
import Rules from "./pages/Rules";
import TeamEntry from "./pages/TeamEntry";

function Router() {
  const [location] = useLocation();
  return <AnimatePresence mode="wait" initial={false}><motion.div key={location} className="bb-route-transition" initial={{ opacity: 0, y: 9, filter: "blur(5px)" }} animate={{ opacity: 1, y: 0, filter: "blur(0px)" }} exit={{ opacity: 0, y: -7, filter: "blur(4px)" }} transition={{ duration: .28, ease: [0.23, 1, 0.32, 1] }}><Switch>
    <Route path="/" component={TeamEntry} />
    <Route path="/dashboard" component={Dashboard} />
    <Route path="/cards" component={MyCards} />
    <Route path="/bazaar" component={Bazaar} />
    <Route path="/leaderboard" component={Leaderboard} />
    <Route path="/rules" component={Rules} />
    <Route path="/404" component={NotFound} />
    <Route component={NotFound} />
  </Switch></motion.div></AnimatePresence>;
}

export default function App() {
  return <ErrorBoundary><ThemeProvider defaultTheme="dark"><TooltipProvider><div className="bb-ambient-canvas"><Toaster richColors theme="dark" position="top-center" /><Router /></div></TooltipProvider></ThemeProvider></ErrorBoundary>;
}
