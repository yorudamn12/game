import { useEffect, useRef } from "react";
import { gsap } from "gsap";
import "./BounceCards.css";
import { PuzzleCardPreview, type PuzzleCard } from "./PuzzleCardPreview";

type BounceCardsProps = { className?: string; cards: PuzzleCard[]; containerWidth?: number; containerHeight?: number; animationDelay?: number; animationStagger?: number; transformStyles?: string[]; enableHover?: boolean; onCardClick?: (card: PuzzleCard) => void };

export default function BounceCards({ className = "", cards, containerWidth = 500, containerHeight = 250, animationDelay = .25, animationStagger = .1, transformStyles = ["rotate(-8deg) translate(-128px, 8px)", "rotate(-2deg) translate(-57px, -6px)", "rotate(4deg) translate(18px, 0)", "rotate(8deg) translate(94px, 11px)"], enableHover = true, onCardClick }: BounceCardsProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const ctx = gsap.context(() => { gsap.fromTo(".bb-card-stack", { scale: .95, opacity: 0 }, { scale: 1, opacity: 1, stagger: animationStagger, ease: "back.out(1.4)", delay: animationDelay, duration: .55 }); }, containerRef);
    return () => ctx.revert();
  }, [animationDelay, animationStagger]);
  const push = (hoveredIndex: number) => {
    if (!enableHover || !containerRef.current) return;
    cards.forEach((_, index) => { const base = transformStyles[index] || "none"; const target = containerRef.current?.querySelector(`.bb-card-${index}`); if (!target) return; const transform = index === hoveredIndex ? base.replace(/rotate\([^)]*\)/, "rotate(0deg)") : `${base} translate(${index < hoveredIndex ? -60 : 60}px, 0)`; gsap.to(target, { transform, duration: .32, ease: "back.out(1.2)", overwrite: "auto" }); });
  };
  const reset = () => cards.forEach((_, index) => { const target = containerRef.current?.querySelector(`.bb-card-${index}`); if (target) gsap.to(target, { transform: transformStyles[index] || "none", duration: .3, ease: "back.out(1.2)", overwrite: "auto" }); });
  return <div ref={containerRef} className={`bounceCardsContainer ${className}`} style={{ width: containerWidth, height: containerHeight }}>{cards.map((card, index) => <button type="button" aria-label={`Open ${card.id}: ${card.title}`} key={card.id} className={`bb-card-stack bb-card-${index}`} style={{ transform: transformStyles[index] || "none" }} onClick={() => onCardClick?.(card)} onMouseEnter={() => push(index)} onFocus={() => push(index)} onMouseLeave={reset} onBlur={reset}><PuzzleCardPreview card={card} compact interactive /></button>)}</div>;
}
