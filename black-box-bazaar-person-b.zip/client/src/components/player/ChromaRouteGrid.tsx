import { useRef } from "react";
import { gsap } from "gsap";
import { ArrowUpRight, BookOpen, Boxes, Store, Trophy } from "lucide-react";

type RouteCard = { title: string; subtitle: string; href: string; color: string; gradient: string; icon: typeof Boxes };

const routes: RouteCard[] = [
  { title: "My Cards", subtitle: "Flip, solve, or list your hand.", href: "/cards", color: "#a98cff", gradient: "linear-gradient(145deg, #4b3485, #110c27)", icon: Boxes },
  { title: "Bazaar", subtitle: "Browse active trades and prices.", href: "/bazaar", color: "#9df3d1", gradient: "linear-gradient(145deg, #175648, #0d1f25)", icon: Store },
  { title: "Ranks", subtitle: "Track the live score signal.", href: "/leaderboard", color: "#ffcc51", gradient: "linear-gradient(145deg, #634721, #24162f)", icon: Trophy },
  { title: "Rules", subtitle: "Review timing and scoring.", href: "/rules", color: "#ff9b8c", gradient: "linear-gradient(145deg, #733142, #261427)", icon: BookOpen },
];

export default function ChromaRouteGrid({ navigate }: { navigate: (href: string) => void }) {
  const root = useRef<HTMLDivElement>(null);
  const fade = useRef<HTMLDivElement>(null);
  const handleMove = (event: React.PointerEvent<HTMLDivElement>) => {
    const rootElement = root.current;
    if (!rootElement) return;
    const rect = rootElement.getBoundingClientRect();
    gsap.to(rootElement, { "--x": `${event.clientX - rect.left}px`, "--y": `${event.clientY - rect.top}px`, duration: .45, ease: "power3.out", overwrite: true });
    gsap.to(fade.current, { opacity: 0, duration: .2, overwrite: true });
  };
  const handleLeave = () => gsap.to(fade.current, { opacity: 1, duration: .55, overwrite: true });
  return <div ref={root} className="bb-chroma-grid" onPointerMove={handleMove} onPointerLeave={handleLeave} data-manus-editable="redirect-links">{routes.map(route => {
    const Icon = route.icon;
    return <button key={route.href} type="button" className="bb-chroma-route" style={{ "--route-color": route.color, "--route-gradient": route.gradient } as React.CSSProperties} onPointerMove={event => { const rect = event.currentTarget.getBoundingClientRect(); event.currentTarget.style.setProperty("--mouse-x", `${event.clientX - rect.left}px`); event.currentTarget.style.setProperty("--mouse-y", `${event.clientY - rect.top}px`); }} onClick={() => navigate(route.href)}><Icon /><span className="bb-chroma-route-copy"><b>{route.title}</b><small>{route.subtitle}</small></span><ArrowUpRight size={17} /></button>;
  })}<div className="bb-chroma-overlay" /><div ref={fade} className="bb-chroma-fade" /></div>;
}
