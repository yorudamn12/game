import { AnimatePresence, motion } from "framer-motion";
import { useEffect, useState } from "react";

const greetings = ["Hello", "こんにちは", "Bonjour", "Hola", "안녕하세요", "Ciao", "Hallo"];

export default function DynamicGreeting() {
  const [index, setIndex] = useState(0);
  useEffect(() => {
    const timer = window.setInterval(() => setIndex(current => current < greetings.length - 1 ? current + 1 : current), 300);
    return () => window.clearInterval(timer);
  }, []);
  return <section className="bb-dynamic-greeting" aria-label="Greeting in multiple languages"><AnimatePresence mode="popLayout" initial={false}><motion.div key={greetings[index]} initial={{ y: 18, opacity: 0 }} animate={{ y: 0, opacity: 1 }} exit={{ y: -34, opacity: 0 }} transition={{ duration: .2, ease: [0.23, 1, 0.32, 1] }}><i />{greetings[index]}</motion.div></AnimatePresence></section>;
}
