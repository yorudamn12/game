import { motion } from "framer-motion";
import { useState } from "react";
import type { PuzzleCard } from "./PuzzleCardPreview";

export default function FlipPuzzleCard({ card, compact = false, className = "" }: { card: PuzzleCard; compact?: boolean; className?: string }) {
  const [flipped, setFlipped] = useState(false);
  const rows = card.examples.slice(0, compact ? 2 : 3);
  return <button type="button" className={`bb-flip-card ${compact ? "is-compact" : ""} ${className}`} aria-label={`${flipped ? "Hide" : "Reveal"} ${card.id} input and output table`} aria-pressed={flipped} onClick={() => setFlipped(value => !value)}><motion.div className="bb-flip-card-inner" animate={{ rotateY: flipped ? 180 : 0 }} transition={{ duration: .5, ease: [0.77, 0, 0.175, 1] }} style={{ transformStyle: "preserve-3d" }}><div className="bb-flip-card-face bb-flip-card-front"><span>?</span></div><div className="bb-flip-card-face bb-flip-card-back" style={{ transform: "rotateY(180deg)" }}><div className="bb-flip-table"><div><b>INPUT</b><b>→</b><b>OUTPUT</b></div>{rows.map(row => <div key={`${row.input}-${row.output}`}><span>{row.input}</span><span>→</span><span>{row.output}</span></div>)}<div className="is-final"><span>{card.finalInput}</span><span>→</span><span>?</span></div></div></div></motion.div></button>;
}
