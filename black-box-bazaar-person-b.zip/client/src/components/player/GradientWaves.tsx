import { useEffect, useRef } from "react";
import { Mesh, Program, Renderer, Triangle } from "ogl";
import "./GradientWaves.css";

type GradientWavesProps = {
  horizonColor?: string;
  waveColor?: string;
  crestColor?: string;
  speed?: number;
  amplitude?: number;
  waveScale?: number;
  waveRatio?: number;
  swell?: number;
  turbulence?: number;
  tilt?: number;
  zoom?: number;
  height?: number;
  fogDepth?: number;
  brightness?: number;
  opacity?: number;
  mouseInteraction?: boolean;
  parallaxStrength?: number;
  grain?: boolean;
  grainIntensity?: number;
  className?: string;
};

const hexToRgb = (hex: string) => {
  const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
  return result ? [parseInt(result[1], 16) / 255, parseInt(result[2], 16) / 255, parseInt(result[3], 16) / 255] : [1, 1, 1];
};

const vertex = `#version 300 es
in vec2 position;
void main() { gl_Position = vec4(position, 0.0, 1.0); }
`;

const fragment = `#version 300 es
precision highp float;
uniform vec2 iResolution;
uniform float iTime;
uniform float uSpeed;
uniform float uAmplitude;
uniform float uWaveScale;
uniform float uWaveRatio;
uniform float uSwell;
uniform float uTurbulence;
uniform float uTilt;
uniform float uZoom;
uniform float uHeight;
uniform float uFogDepth;
uniform float uBrightness;
uniform float uOpacity;
uniform float uGrain;
uniform float uGrainIntensity;
uniform vec2 uMouse;
uniform float uParallax;
uniform bool uEnableMouse;
uniform vec3 uHorizonColor;
uniform vec3 uWaveColor;
uniform vec3 uCrestColor;
out vec4 fragColor;

float hash21(vec2 p) { vec3 p3 = fract(vec3(p.xyx) * .1031); p3 += dot(p3, p3.yzx + 33.33); return fract((p3.x + p3.y) * p3.z); }
float plasma(vec3 r, vec2 freq, vec4 tc) {
  float mx = r.x + tc.x; mx += uSwell * sin((r.y + mx) / 20. + tc.y);
  float my = r.y - tc.z; my += uTurbulence * cos(r.x / 23. + tc.w);
  return r.z - (sin(mx * freq.x) * uAmplitude + sin(my * freq.y) * uAmplitude + uHeight);
}
float raymarch(vec3 pos, vec3 dir, vec2 freq, vec4 tc) {
  float dist = 0.;
  for (int i = 0; i < 70; i++) { float dscene = plasma(pos + dist * dir, freq, tc); if (abs(dscene) < .1) break; dist += .9 * dscene; if (abs(dist) > 20000.) return 20000.; }
  return dist;
}
void main() {
  float T = iTime * uSpeed; vec2 freq = vec2(uWaveScale / 7., (uWaveScale * uWaveRatio) / 3.); vec4 tc = vec4(T/.13, T/.81, T/.2, T/.71);
  vec2 uv = gl_FragCoord.xy / iResolution.xy - .5; uv.x *= iResolution.x / iResolution.y; uv.y *= -1.;
  vec3 cam = vec3(0., 0., 30.); vec3 dir = normalize(vec3(uv.x / max(uZoom, .05), uv.y, -1.));
  float c = cos(uTilt); float s = sin(uTilt); dir = mat3(c,0.,s, 0.,1.,0., -s,0.,c) * dir;
  if (uEnableMouse) { float yaw = (uMouse.x-.5)*uParallax*.4; float pitch = (uMouse.y-.5)*uParallax*.4; c=cos(yaw); s=sin(yaw); dir=mat3(c,0.,s,0.,1.,0.,-s,0.,c)*dir; c=cos(pitch); s=sin(pitch); dir=mat3(1.,0.,0.,0.,c,-s,0.,s,c)*dir; }
  float dist = raymarch(cam, dir, freq, tc); vec3 pos = cam + dist * dir; float t = clamp(uFogDepth / max(dist, .001), 0., 1.);
  vec3 body = mix(uWaveColor, uCrestColor, clamp(pos.z*.08+.5, 0., 1.)); vec3 col = mix(uHorizonColor, body, t) * uBrightness;
  float alpha = clamp(t, 0., 1.) * uOpacity; if (uGrain > .5) alpha += (hash21(gl_FragCoord.xy + mod(iTime,64.)*11.)-.5)*uGrainIntensity;
  fragColor = vec4(clamp(col,0.,1.) * clamp(alpha,0.,1.), clamp(alpha,0.,1.));
}`;

export default function GradientWaves({
  horizonColor = "#4e28a5", waveColor = "#18145c", crestColor = "#a5ffd5", speed = 0.18, amplitude = 2.25,
  waveScale = 0.65, waveRatio = 0.9, swell = 20, turbulence = 15, tilt = 1.12, zoom = 1, height = 5.5,
  fogDepth = 22, brightness = 1.15, opacity = 0.62, mouseInteraction = true, parallaxStrength = 0.28,
  grain = true, grainIntensity = 0.035, className = "",
}: GradientWavesProps) {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const container = containerRef.current;
    if (!container || !window.WebGL2RenderingContext) return;
    const renderer = new Renderer({ webgl: 2, alpha: true, premultipliedAlpha: true, antialias: false, dpr: Math.min(window.devicePixelRatio || 1, 2) });
    const gl = renderer.gl;
    const canvas = gl.canvas;
    canvas.style.cssText = "width:100%;height:100%;display:block";
    container.appendChild(canvas);
    const program = new Program(gl, {
      vertex, fragment,
      uniforms: {
        iTime: { value: 0 }, iResolution: { value: new Float32Array([1, 1]) }, uSpeed: { value: speed }, uAmplitude: { value: amplitude }, uWaveScale: { value: waveScale }, uWaveRatio: { value: waveRatio }, uSwell: { value: swell }, uTurbulence: { value: turbulence }, uTilt: { value: tilt }, uZoom: { value: zoom }, uHeight: { value: height }, uFogDepth: { value: fogDepth }, uBrightness: { value: brightness }, uOpacity: { value: opacity }, uGrain: { value: grain ? 1 : 0 }, uGrainIntensity: { value: grainIntensity }, uMouse: { value: new Float32Array([.5, .5]) }, uParallax: { value: parallaxStrength }, uEnableMouse: { value: mouseInteraction }, uHorizonColor: { value: new Float32Array(hexToRgb(horizonColor)) }, uWaveColor: { value: new Float32Array(hexToRgb(waveColor)) }, uCrestColor: { value: new Float32Array(hexToRgb(crestColor)) },
      },
    });
    const mesh = new Mesh(gl, { geometry: new Triangle(gl), program });
    const targetMouse = [.5, .5]; const currentMouse = [.5, .5];
    const resize = () => { const rect = container.getBoundingClientRect(); renderer.setSize(Math.max(1, rect.width), Math.max(1, rect.height)); const resolution = program.uniforms.iResolution.value as Float32Array; resolution[0] = gl.drawingBufferWidth; resolution[1] = gl.drawingBufferHeight; };
    const onPointerMove = (event: PointerEvent) => { const rect = canvas.getBoundingClientRect(); targetMouse[0] = (event.clientX - rect.left) / rect.width; targetMouse[1] = 1 - (event.clientY - rect.top) / rect.height; };
    const resetPointer = () => { targetMouse[0] = .5; targetMouse[1] = .5; };
    const observer = new ResizeObserver(resize); observer.observe(container); resize();
    canvas.addEventListener("pointermove", onPointerMove); canvas.addEventListener("pointerleave", resetPointer);
    const startedAt = performance.now(); let frame = 0;
    const render = (time: number) => { program.uniforms.iTime.value = (time - startedAt) * .001; currentMouse[0] += .045 * (targetMouse[0] - currentMouse[0]); currentMouse[1] += .045 * (targetMouse[1] - currentMouse[1]); const mouse = program.uniforms.uMouse.value as Float32Array; mouse[0] = currentMouse[0]; mouse[1] = currentMouse[1]; renderer.render({ scene: mesh }); frame = requestAnimationFrame(render); };
    frame = requestAnimationFrame(render);
    return () => { cancelAnimationFrame(frame); observer.disconnect(); canvas.removeEventListener("pointermove", onPointerMove); canvas.removeEventListener("pointerleave", resetPointer); container.removeChild(canvas); gl.getExtension("WEBGL_lose_context")?.loseContext(); };
  }, []);
  return <div ref={containerRef} aria-hidden="true" className={`gradient-waves-container ${className}`.trim()} />;
}

