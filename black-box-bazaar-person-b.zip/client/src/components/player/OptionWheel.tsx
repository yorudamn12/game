import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import "./OptionWheel.css";

type OptionWheelProps = {
  items: string[];
  defaultSelected?: number;
  onChange?: (index: number, item: string) => void;
  textColor?: string;
  activeColor?: string;
  side?: "left" | "right";
  fontSize?: number;
  spacing?: number;
  curve?: number;
  tilt?: number;
  blur?: number;
  fade?: number;
  minOpacity?: number;
  smoothing?: number;
  inset?: number;
  loop?: boolean;
  draggable?: boolean;
  className?: string;
};

export default function OptionWheel({ items, defaultSelected = 0, onChange, textColor = "#857b99", activeColor = "#a5ffd5", side = "left", fontSize = 1.05, spacing = 2.25, curve = .62, tilt = 11, blur = .4, fade = .26, minOpacity = .15, smoothing = 180, inset = 18, loop = false, draggable = true, className = "" }: OptionWheelProps) {
  const rootRef = useRef<HTMLDivElement>(null);
  const itemRefs = useRef<Array<HTMLButtonElement | null>>([]);
  const posRef = useRef(defaultSelected); const targetRef = useRef(defaultSelected); const rafRef = useRef<number | null>(null); const lastRef = useRef(0); const dragRef = useRef<{ y: number; start: number; moved: boolean } | null>(null);
  const [selectedIndex, setSelectedIndex] = useState(defaultSelected);
  const config = useMemo(() => ({ rowH: Math.max(fontSize * spacing * 16, 1), count: items.length }), [fontSize, spacing, items.length]);

  const applyLayout = useCallback((now: number) => {
    const dt = Math.min((now - lastRef.current) / 1000, .05); lastRef.current = now;
    const k = 1 - Math.exp(-dt / Math.max(smoothing, 1) * 1000);
    let next = posRef.current + (targetRef.current - posRef.current) * k;
    const settled = Math.abs(next - targetRef.current) < .001; if (settled) next = targetRef.current; posRef.current = next;
    const angle = tilt * Math.PI / 180; const radius = angle ? config.rowH / angle : 0; const mirror = side === "right" ? -1 : 1;
    itemRefs.current.forEach((element, index) => { if (!element) return; const distance = index - next; const limitedAngle = Math.max(-Math.PI / 2, Math.min(Math.PI / 2, distance * angle)); const y = radius ? radius * Math.sin(limitedAngle) : distance * config.rowH; const x = radius ? -mirror * radius * (1 - Math.cos(limitedAngle)) * curve : 0; element.style.transform = `translate(${x}px, calc(${y}px - 50%)) rotate(${mirror * limitedAngle * 180 / Math.PI}deg)`; element.style.opacity = String(Math.max(minOpacity, 1 - Math.abs(distance) * fade)); element.style.filter = `blur(${Math.abs(distance) * blur}px)`; element.style.setProperty("--ow-p", String(Math.max(0, 1 - Math.min(Math.abs(distance), 1)))); });
    rafRef.current = settled ? null : requestAnimationFrame(applyLayout);
  }, [blur, config.rowH, curve, fade, minOpacity, side, smoothing, tilt]);

  const setTarget = useCallback((value: number, emit = true) => { const next = loop ? ((Math.round(value) % items.length) + items.length) % items.length : Math.min(Math.max(Math.round(value), 0), items.length - 1); targetRef.current = next; if (next !== selectedIndex) { setSelectedIndex(next); if (emit) onChange?.(next, items[next]); } if (rafRef.current === null) { lastRef.current = performance.now(); rafRef.current = requestAnimationFrame(applyLayout); } }, [applyLayout, items, loop, onChange, selectedIndex]);

  useEffect(() => { setTarget(defaultSelected, false); }, [defaultSelected, setTarget]);
  useEffect(() => () => { if (rafRef.current) cancelAnimationFrame(rafRef.current); }, []);

  const onWheel = (event: React.WheelEvent) => { event.preventDefault(); setTarget(targetRef.current + (event.deltaY > 0 ? 1 : -1)); };
  const pointerDown = (event: React.PointerEvent) => { if (!draggable) return; dragRef.current = { y: event.clientY, start: targetRef.current, moved: false }; };
  const pointerMove = (event: React.PointerEvent) => { const drag = dragRef.current; if (!drag) return; const delta = event.clientY - drag.y; if (Math.abs(delta) > 5) drag.moved = true; if (drag.moved) setTarget(drag.start - delta / config.rowH, false); };
  const pointerUp = () => { if (dragRef.current?.moved) setTarget(targetRef.current); dragRef.current = null; };
  return <div ref={rootRef} role="listbox" tabIndex={0} aria-label="Primary navigation wheel" className={`option-wheel ${side === "right" ? "option-wheel--right" : ""} ${className}`} style={{ "--ow-text-color": textColor, "--ow-active-color": activeColor, "--ow-font-size": `${fontSize}rem`, "--ow-inset": `${inset}px` } as React.CSSProperties} onWheel={onWheel} onPointerDown={pointerDown} onPointerMove={pointerMove} onPointerUp={pointerUp} onPointerCancel={pointerUp} onKeyDown={event => { if (event.key === "ArrowUp") { event.preventDefault(); setTarget(targetRef.current - 1); } if (event.key === "ArrowDown") { event.preventDefault(); setTarget(targetRef.current + 1); } }}>{items.map((item, index) => <button key={item} ref={element => { itemRefs.current[index] = element; }} type="button" role="option" aria-selected={index === selectedIndex} className={`option-wheel__item ${index === selectedIndex ? "option-wheel__item--selected" : ""}`} onClick={() => setTarget(index)}>{item}</button>)}</div>;
}

