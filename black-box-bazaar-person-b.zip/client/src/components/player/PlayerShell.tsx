import type { ReactNode } from "react";
import { useEffect } from "react";
import { BarChart3, BookOpen, Boxes, Home, LogOut, Store, Trophy } from "lucide-react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { useGameState, useOwnedCards, usePlayerSession, useRealtimeGameUpdates, useTeam } from "@/hooks/usePlayerGame";
import SmoothTabs from "./SmoothTabs";
import "./PlayerRefinement.css";

const navigation = [
  { href: "/dashboard", label: "Home", icon: Home },
  { href: "/cards", label: "My Cards", icon: Boxes },
  { href: "/bazaar", label: "Bazaar", icon: Store },
  { href: "/leaderboard", label: "Ranks", icon: Trophy },
  { href: "/rules", label: "Rules", icon: BookOpen },
];

export function PlayerShell({ children }: { children: (data: any, sessionToken: string) => ReactNode }) {
  const [location, navigate] = useLocation();
  const { sessionToken, clearSession } = usePlayerSession();
  const teamQuery = useTeam(sessionToken);
  const ownedCardsQuery = useOwnedCards(sessionToken);
  const gameStateQuery = useGameState();
  useRealtimeGameUpdates(Boolean(sessionToken));

  useEffect(() => { if (!sessionToken) navigate("/"); }, [navigate, sessionToken]);
  useEffect(() => {
    if (teamQuery.error?.message.includes("session")) { clearSession(); navigate("/"); }
  }, [clearSession, navigate, teamQuery.error]);

  if (!sessionToken) return null;
  if (teamQuery.isLoading) return <div className="bb-loading-screen"><div className="bb-loading-orb" /><p>Opening your black box...</p></div>;
  if (teamQuery.error || !teamQuery.data) return <main className="bb-fallback"><p>Your game session needs a fresh start.</p><Button onClick={() => { clearSession(); navigate("/"); }}>Return to Team Entry</Button></main>;

  const data = {
    ...teamQuery.data,
    cards: ownedCardsQuery.data,
    game: gameStateQuery.data || teamQuery.data.game,
  };
  return <div className="bb-app-shell">
    <header className="bb-topbar">
      <button type="button" className="bb-brand" onClick={() => navigate("/dashboard")} aria-label="Go to dashboard">
        <span className="bb-brand-mark"><span>?</span></span>
        <span><b>BLACK BOX</b><em>BAZAAR</em></span>
      </button>
      <div className="bb-topbar-meta">
        <span className="bb-phase-pill"><i />{data.game.phase}</span>
        <button type="button" className="bb-logout" onClick={() => { clearSession(); navigate("/"); }} aria-label="End team session"><LogOut size={17} /></button>
      </div>
    </header>
    <nav className="bb-desktop-tabs"><SmoothTabs items={navigation.map(item => ({ id: item.href, label: item.label }))} activeId={location} onChange={navigate} className="desktop" /></nav>
    <main className="bb-main">{children(data, sessionToken)}</main>
    <nav className="bb-bottom-nav"><SmoothTabs items={navigation.map(item => ({ id: item.href, label: item.label }))} activeId={location} onChange={navigate} className="mobile" /></nav>
  </div>;
}

function NavButton({ item, active, navigate, compact = false }: { item: (typeof navigation)[number]; active: boolean; navigate: (path: string) => void; compact?: boolean }) {
  const Icon = item.icon;
  return <button type="button" className={`bb-nav-button ${active ? "is-active" : ""} ${compact ? "is-compact" : ""}`} onClick={() => navigate(item.href)}><Icon size={compact ? 18 : 17} /><span>{item.label}</span></button>;
}

export function SectionHeading({ eyebrow, title, description, action }: { eyebrow?: string; title: string; description?: string; action?: ReactNode }) {
  return <div className="bb-section-heading"><div>{eyebrow && <p className="bb-eyebrow">{eyebrow}</p>}<h1>{title}</h1>{description && <p>{description}</p>}</div>{action}</div>;
}

export function PhaseNotice({ phase, action }: { phase: string; action: string }) {
  const copy = phase === "BAZAAR" ? `${action} is live during BAZAAR.` : phase === "SUBMISSION" ? `${action} is available only while the SUBMISSION phase is open.` : phase === "REGISTRATION" ? `The game is in REGISTRATION. ${action} will open when the Bazaar begins.` : phase === "REVEAL" ? `The game is in REVEAL. ${action} is locked while results are revealed.` : `GAME OVER: ${action} is no longer available.`;
  return <div className="bb-phase-notice"><BarChart3 size={17} /><span>{copy}</span></div>;
}
