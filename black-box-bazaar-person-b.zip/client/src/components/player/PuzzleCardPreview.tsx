import "./PuzzleCardPreview.css";

export type PuzzleCard = { id: string; title: string; tier: string; status: "available" | "listed" | "submitted" | "sold"; examples: Array<{ input: string; output: string }>; finalInput: string; listing?: { price: number } | null; };

export function PuzzleCardPreview({ card, compact = false, interactive = false }: { card: PuzzleCard; compact?: boolean; interactive?: boolean }) {
  return <div className={`bb-puzzle-card-preview bb-tier-${card.tier} ${compact ? "is-compact" : ""} ${interactive ? "is-interactive" : ""}`}><header><span>BLACK BOX / {card.id}</span><b>TIER {card.tier}</b></header><div className="bb-preview-question">?</div>{card.status === "listed" && <footer><i />LIVE IN BAZAAR <b>{card.listing?.price || "—"} BB</b></footer>}</div>;
}
