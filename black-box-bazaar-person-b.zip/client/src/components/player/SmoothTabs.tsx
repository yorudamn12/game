import { motion } from "framer-motion";

export type SmoothTabItem = { id: string; label: string };

export default function SmoothTabs({ items, activeId, onChange, className = "" }: { items: SmoothTabItem[]; activeId: string; onChange: (id: string) => void; className?: string }) {
  return <div className={`bb-smooth-tabs ${className}`} role="tablist" aria-label="Primary navigation">{items.map(item => {
    const active = item.id === activeId;
    return <button type="button" key={item.id} role="tab" aria-selected={active} className={active ? "is-active" : ""} onClick={() => onChange(item.id)}>{active && <motion.span layoutId={`smooth-tab-${className || "player"}`} className="bb-smooth-tab-indicator" transition={{ type: "spring", stiffness: 410, damping: 32 }} />}{item.label}</button>;
  })}</div>;
}
