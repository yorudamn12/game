import { useEffect, useRef, useState } from "react";
import { gsap } from "gsap";
import "./TextType.css";

type TextTypeProps = { text: string; as?: "h1" | "h2" | "div" | "p"; typingSpeed?: number; initialDelay?: number; className?: string; showCursor?: boolean; cursorCharacter?: string; cursorClassName?: string; cursorBlinkDuration?: number; };

export default function TextType({ text, as: Tag = "div", typingSpeed = 48, initialDelay = 180, className = "", showCursor = true, cursorCharacter = "|", cursorClassName = "", cursorBlinkDuration = .5 }: TextTypeProps) {
  const [displayed, setDisplayed] = useState(""); const cursorRef = useRef<HTMLSpanElement>(null);
  useEffect(() => { setDisplayed(""); let index = 0; const start = window.setTimeout(() => { const timer = window.setInterval(() => { index += 1; setDisplayed(text.slice(0, index)); if (index >= text.length) window.clearInterval(timer); }, typingSpeed); return () => window.clearInterval(timer); }, initialDelay); return () => window.clearTimeout(start); }, [initialDelay, text, typingSpeed]);
  useEffect(() => { if (showCursor && cursorRef.current) gsap.to(cursorRef.current, { opacity: 0, duration: cursorBlinkDuration, repeat: -1, yoyo: true, ease: "power2.inOut" }); }, [cursorBlinkDuration, showCursor]);
  return <Tag className={`text-type ${className}`}><span className="text-type__content" style={{ color: "#d8cfcf" }}>{displayed}</span>{showCursor && <span ref={cursorRef} className={`text-type__cursor ${cursorClassName}`} style={{ color: "#ffffff" }}>{cursorCharacter}</span>}</Tag>;
}
