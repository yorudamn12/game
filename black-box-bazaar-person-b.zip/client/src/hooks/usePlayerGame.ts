import { useCallback, useEffect, useState } from "react";
import { trpc } from "@/lib/trpc";

const PLAYER_SESSION_KEY = "black-box-bazaar-player-session";

export function usePlayerSession() {
  const [sessionToken, setSessionTokenState] = useState<string | null>(() => localStorage.getItem(PLAYER_SESSION_KEY));
  const setSessionToken = useCallback((token: string) => { localStorage.setItem(PLAYER_SESSION_KEY, token); setSessionTokenState(token); }, []);
  const clearSession = useCallback(() => { localStorage.removeItem(PLAYER_SESSION_KEY); setSessionTokenState(null); }, []);
  return { sessionToken, setSessionToken, clearSession };
}

const queryOptions = { refetchOnWindowFocus: true, retry: 1 };

export function useRealtimeGameUpdates(enabled: boolean) {
  const utils = trpc.useUtils();
  useEffect(() => {
    if (!enabled) return;
    const source = new EventSource("/api/game-events");
    const refresh = () => { void Promise.all([utils.game.dashboard.invalidate(), utils.game.marketplace.invalidate(), utils.game.leaderboard.invalidate(), utils.game.state.invalidate()]); };
    source.addEventListener("game:update", refresh);
    return () => { source.removeEventListener("game:update", refresh); source.close(); };
  }, [enabled, utils]);
}

export function useTeam(sessionToken: string | null) {
  return trpc.game.dashboard.useQuery({ sessionToken: sessionToken || "" }, { ...queryOptions, enabled: Boolean(sessionToken) });
}

export function useOwnedCards(sessionToken: string | null) {
  const teamQuery = useTeam(sessionToken);
  return { ...teamQuery, data: teamQuery.data?.cards || [] };
}

export function useMarketplace(sessionToken: string | null) {
  return trpc.game.marketplace.useQuery({ sessionToken: sessionToken || "" }, { ...queryOptions, enabled: Boolean(sessionToken) });
}

export function useGameState() {
  return trpc.game.state.useQuery(undefined, queryOptions);
}

export function useLeaderboard() {
  return trpc.game.leaderboard.useQuery(undefined, queryOptions);
}

export function useGameActions() {
  const utils = trpc.useUtils();
  const refresh = async () => { await Promise.all([utils.game.dashboard.invalidate(), utils.game.marketplace.invalidate(), utils.game.leaderboard.invalidate(), utils.game.state.invalidate()]); };
  const createListing = trpc.game.createListing.useMutation({ onSuccess: refresh });
  const requestPurchase = trpc.game.requestPurchase.useMutation({ onSuccess: refresh });
  const confirmTrade = trpc.game.confirmTrade.useMutation({ onSuccess: refresh });
  const cancelTrade = trpc.game.cancelTrade.useMutation({ onSuccess: refresh });
  const rejectTrade = trpc.game.rejectTrade.useMutation({ onSuccess: refresh });
  const submitAnswer = trpc.game.submitAnswer.useMutation({ onSuccess: refresh });
  return { createListing, requestPurchase, confirmTrade, cancelTrade, rejectTrade, submitAnswer };
}
