import { ArrowUpRight, Boxes, CircleDollarSign, Compass, Sparkles, Trophy } from "lucide-react";
import ChromaRouteGrid from "@/components/player/ChromaRouteGrid";
import { PlayerShell, SectionHeading } from "@/components/player/PlayerShell";
import TextType from "@/components/player/TextType";
import FlipPuzzleCard from "@/components/player/FlipPuzzleCard";
import { useLocation } from "wouter";

export default function Dashboard() {
  const [, navigate] = useLocation();
  return <PlayerShell>{data => <>
    <section className="bb-dashboard-welcome" data-manus-editable="dashboard-welcome"><div><TextType as="h1" className="bb-typed-welcome" text={`Welcome back, ${data.team.teamName}.`} typingSpeed={42} initialDelay={250} cursorCharacter="|" /><p>Compile your hunches, debug the patterns, and trade only when your logic is worth more than your BitBucks.</p></div>{data.cards[0] ? <FlipPuzzleCard card={data.cards[0]} compact className="bb-hero-flip" /> : null}</section>
    <section className="bb-stat-grid" aria-label="Team metrics" data-manus-editable="metrics">
      <Metric icon={<Trophy size={19} />} label="Current Score" value={data.team.score} accent="violet" />
      <Metric icon={<CircleDollarSign size={19} />} label="BitBucks" value={data.team.bitBucks} accent="mint" />
      <Metric icon={<Boxes size={19} />} label="Owned Cards" value={data.cards.length} suffix="in hand" accent="gold" />
    </section>
    <section className="bb-dashboard-grid" data-manus-editable="game-information">
      <div className="bb-open-info bb-status-info" data-manus-editable="game-status"><div className="bb-card-label"><Sparkles size={17} /><span>GAME STATUS</span></div><p className="bb-status-phase">{data.game.phase}</p><p>{data.game.phase === "BAZAAR" ? "The market is open. Price your knowledge well." : data.game.phase === "SUBMISSION" ? "Lock in your final solutions before the reveal." : "Watch the game phase and be ready for your next move."}</p><button type="button" className="bb-glass-action" onClick={() => navigate("/rules")}>How to Play <ArrowUpRight size={15} /></button></div>
      <div className="bb-open-info bb-next-info" data-manus-editable="next-move"><div className="bb-card-label"><Compass size={17} /><span>YOUR NEXT MOVE</span></div><h2>{data.cards.some((card: any) => card.status === "available") ? "A box is waiting." : "Your hand is in motion."}</h2><p>{data.cards.some((card: any) => card.status === "available") ? "Review your available cards, decide what you know, and trade only when the odds are in your favor." : "Check Bazaar trade confirmations or keep an eye on the leaderboard."}</p><button type="button" className="bb-glass-action" onClick={() => navigate(data.cards.some((card: any) => card.status === "available") ? "/cards" : "/bazaar")}>Take me there <ArrowUpRight size={16} /></button></div>
    </section>
    {data.cards.some((card: any) => card.status === "listed") && <section className="bb-dashboard-listings"><SectionHeading eyebrow="LIVE BAZAAR SIGNAL" title="Your listed cards" description="Tap a card to flip to its input/output table." /><div className="bb-dashboard-listing-grid">{data.cards.filter((card: any) => card.status === "listed").map((card: any) => <FlipPuzzleCard key={card.id} card={card} compact />)}</div></section>}
    <section className="bb-quick-section"><SectionHeading eyebrow="FAST LANES" title="Choose your next move" /><ChromaRouteGrid navigate={navigate} /></section>
  </>}</PlayerShell>;
}

function Metric({ icon, label, value, suffix, accent }: { icon: React.ReactNode; label: string; value: number; suffix?: string; accent: string }) { return <article className={`bb-metric bb-accent-${accent}`}><div>{icon}</div><p>{label}</p><strong>{value}</strong>{suffix && <span>{suffix}</span>}</article>; }
