import { Crown, RefreshCw, Trophy } from "lucide-react";
import { PlayerShell, SectionHeading } from "@/components/player/PlayerShell";
import { useLeaderboard } from "@/hooks/usePlayerGame";

export default function Leaderboard() {
  const board = useLeaderboard();
  return <PlayerShell>{data => <>
    <SectionHeading eyebrow="LIVE RANKINGS" title="The leaderboard" description="Rank is driven by puzzle score, with BitBucks resolving any tie." action={<span className="bb-live-indicator"><i />LIVE <RefreshCw size={13} /></span>} />
    <section className="bb-leaderboard-card" data-manus-editable="leaderboard"><div className="bb-board-head"><span>Rank</span><span>Team</span><span>Score</span><span>BitBucks</span></div>{board.isLoading ? <div className="bb-board-loading">Calculating ranks...</div> : board.data?.map(row => <div className={`bb-board-row ${row.teamId === data.team.id ? "is-current" : ""}`} key={row.teamId} data-manus-editable={`ranking-${row.teamId}`}><span className="bb-rank">{row.rank === 1 ? <Crown size={19} /> : `#${String(row.rank).padStart(2, "0")}`}</span><span><b>{row.teamName}</b>{row.teamId === data.team.id && <em>YOUR TEAM</em>}</span><strong>{row.score}</strong><span>{row.bitBucks} <small>BB</small></span></div>)}</section>
    <section className="bb-rank-explainer" data-manus-editable="rank-explainer"><Trophy size={19} /><p><b>How ranks work.</b> Teams are ordered by the highest puzzle score first. BitBucks are only used as the tie-breaker.</p></section>
  </>}</PlayerShell>;
}
