import { useState } from "react";
import { CheckCircle2, CircleDollarSign, LockKeyhole, Send, Store } from "lucide-react";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import FlipPuzzleCard from "@/components/player/FlipPuzzleCard";
import { PlayerShell, PhaseNotice, SectionHeading } from "@/components/player/PlayerShell";
import { useGameActions } from "@/hooks/usePlayerGame";
import { toast } from "sonner";

type CardModel = any;

export default function MyCards() {
  const [sellCard, setSellCard] = useState<CardModel | null>(null);
  const [solveCard, setSolveCard] = useState<CardModel | null>(null);
  return <PlayerShell>{(data, sessionToken) => <>
    <SectionHeading eyebrow="YOUR VAULT" title="My Cards" description="Tap a card to flip it and see only its input/output table." />
    {data.cards.length === 0 ? <div className="bb-empty-state" data-manus-editable="empty-vault"><Store size={28} /><h2>Your vault is empty.</h2><p>Sold cards leave your vault after both teams confirm the trade.</p></div> : <section className="bb-simple-card-grid" data-manus-editable="owned-card-grid">{data.cards.map((card: CardModel) => <PlayerCard key={card.id} card={card} phase={data.game.phase} onSell={() => setSellCard(card)} onSolve={() => setSolveCard(card)} />)}</section>}
    {data.game.phase !== "BAZAAR" && data.game.phase !== "SUBMISSION" && <PhaseNotice phase={data.game.phase} action="Card actions" />}
    <SellDialog card={sellCard} sessionToken={sessionToken} onOpenChange={open => !open && setSellCard(null)} />
    <SolveDialog card={solveCard} sessionToken={sessionToken} onOpenChange={open => !open && setSolveCard(null)} />
  </>}</PlayerShell>;
}

function PlayerCard({ card, phase, onSell, onSolve }: { card: CardModel; phase: string; onSell: () => void; onSolve: () => void }) {
  const canSell = card.status === "available" && phase === "BAZAAR";
  const canSolve = card.status === "available" && phase === "SUBMISSION";
  const stateDetail = card.status === "listed" ? `listed · ${card.listing?.price || "—"} BB` : card.status;
  return <article className="bb-simple-card" data-manus-editable={`card-${card.id}`}><div className="bb-simple-card-meta"><b>{card.id}</b><span>{stateDetail}</span></div><FlipPuzzleCard card={card} />{card.status === "available" ? <div className="bb-card-action-row"><button type="button" disabled={!canSolve} onClick={onSolve} className="bb-card-solve">Solve</button><button type="button" disabled={!canSell} onClick={onSell} className="bb-card-sell">Sell</button></div> : card.status === "submitted" ? <p className="bb-simple-card-note">Submitted / waiting for reveal</p> : <p className="bb-simple-card-note">Live in Bazaar / answer entry is locked</p>}</article>;
}

function SellDialog({ card, sessionToken, onOpenChange }: { card: CardModel | null; sessionToken: string; onOpenChange: (open: boolean) => void }) {
  const [price, setPrice] = useState("25");
  const { createListing } = useGameActions();
  const submit = async (event: React.FormEvent) => { event.preventDefault(); if (!card) return; try { await createListing.mutateAsync({ sessionToken, cardId: card.id, price: Number(price) }); toast.success(`${card.id} is now listed in the Bazaar.`); onOpenChange(false); } catch (error: any) { toast.error(error.message || "We could not list this card."); } };
  return <Dialog open={Boolean(card)} onOpenChange={onOpenChange}><DialogContent className="bb-dialog-content"><DialogHeader><DialogTitle>List {card?.id} for sale</DialogTitle><DialogDescription>Choose a price in BitBucks. Your card stays in your vault as listed until a trade is completed.</DialogDescription></DialogHeader><form onSubmit={submit} className="bb-modal-form"><label>Asking price <div className="bb-price-field"><CircleDollarSign size={18} /><input type="number" min="1" max="1000" value={price} onChange={event => setPrice(event.target.value)} required /></div></label><p className="bb-safe-note"><CheckCircle2 size={16} />A buyer must request the listing, then both sides must confirm before ownership and BitBucks move.</p><button type="submit" className="bb-primary-action" disabled={createListing.isPending}>{createListing.isPending ? "Creating listing..." : "List for sale"}</button></form></DialogContent></Dialog>;
}

function SolveDialog({ card, sessionToken, onOpenChange }: { card: CardModel | null; sessionToken: string; onOpenChange: (open: boolean) => void }) {
  const [answer, setAnswer] = useState("");
  const [confidence, setConfidence] = useState<"low" | "medium" | "high">("medium");
  const [confirming, setConfirming] = useState(false);
  const { submitAnswer } = useGameActions();
  const lockAnswer = async () => { if (!card) return; try { await submitAnswer.mutateAsync({ sessionToken, cardId: card.id, answer, confidence }); toast.success("Answer submitted / waiting for reveal. The correct answer has not been shown."); setConfirming(false); onOpenChange(false); } catch (error: any) { toast.error(error.message || "We could not lock your answer."); } };
  return <Dialog open={Boolean(card)} onOpenChange={onOpenChange}><DialogContent className="bb-dialog-content"><DialogHeader><DialogTitle>Solve {card?.id}</DialogTitle><DialogDescription>Write the final output or rule you believe solves this card. Correct answers are never revealed in submission feedback.</DialogDescription></DialogHeader>{!confirming ? <form className="bb-modal-form" onSubmit={event => { event.preventDefault(); setConfirming(true); }}><label>Your final answer<textarea value={answer} onChange={event => setAnswer(event.target.value)} placeholder="Enter the output or your rule..." required maxLength={200} /></label><label>Confidence<select value={confidence} onChange={event => setConfidence(event.target.value as "low" | "medium" | "high")}><option value="low">Low</option><option value="medium">Medium</option><option value="high">High</option></select></label><div className="bb-final-warning"><LockKeyhole size={18} /><span><b>This submission is final.</b> Once locked, it cannot be edited or submitted again for this card.</span></div><button type="submit" className="bb-primary-action"><Send size={17} />Review final submission</button></form> : <div className="bb-confirm-pane"><div className="bb-confirm-symbol">!</div><h3>Lock this answer?</h3><p>Your team will see <b>submitted / waiting for reveal</b>. No correct answer or solution will be returned.</p><div className="bb-confirm-actions"><button type="button" className="bb-secondary-action" onClick={() => setConfirming(false)}>Go back</button><button type="button" className="bb-primary-action" onClick={lockAnswer} disabled={submitAnswer.isPending}>{submitAnswer.isPending ? "Locking..." : "Lock final answer"}</button></div></div>}</DialogContent></Dialog>;
}
