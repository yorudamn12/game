import { useEffect, useState } from "react";
import { CheckCircle2, KeyRound, LoaderCircle, LockKeyhole, ShieldCheck, TriangleAlert } from "lucide-react";
import { useLocation } from "wouter";
import GradientWaves from "@/components/player/GradientWaves";
import DynamicGreeting from "@/components/player/DynamicGreeting";
import { trpc } from "@/lib/trpc";
import { usePlayerSession } from "@/hooks/usePlayerGame";

type EntryState = "idle" | "loading" | "invalid" | "success";

export default function TeamEntry() {
  const [, navigate] = useLocation();
  const { sessionToken, setSessionToken } = usePlayerSession();
  const [teamNumber, setTeamNumber] = useState("");
  const [teamPin, setTeamPin] = useState("");
  const [entryState, setEntryState] = useState<EntryState>("idle");
  const [successTeam, setSuccessTeam] = useState("");
  const login = trpc.game.login.useMutation({
    onSuccess: data => { setSuccessTeam(data.team.teamName); setSessionToken(data.sessionToken); setEntryState("success"); },
    onError: () => setEntryState("invalid"),
  });

  useEffect(() => { if (sessionToken) navigate("/dashboard"); }, [navigate, sessionToken]);
  useEffect(() => { if (entryState !== "success") return; const timer = window.setTimeout(() => navigate("/dashboard"), 1050); return () => window.clearTimeout(timer); }, [entryState, navigate]);

  const handleSubmit = (event: React.FormEvent) => {
    event.preventDefault();
    setEntryState("loading");
    login.mutate({ teamNumber: Number(teamNumber), teamPin });
  };

  return <main className="bb-entry-page">
    <GradientWaves horizonColor="#6c3ecf" waveColor="#170b3b" crestColor="#c5ffd7" speed={.13} amplitude={2.3} swell={25} turbulence={17} className="bb-entry-waves" />
    <div className="bb-entry-grid" aria-hidden="true" />
    <section className="bb-entry-card">
      <div className="bb-entry-brand"><span className="bb-entry-cube">?</span><div><p>CODING CLUB RVCE</p><h1>BLACK BOX <strong>BAZAAR</strong></h1></div></div>
      <DynamicGreeting />
      <div className="bb-entry-copy"><span className="bb-kicker">TEAM ACCESS</span><h2>Enter the trading floor.</h2><p>Use your team number and secure PIN to open your allocated cards, BitBucks, and live game state.</p></div>
      {entryState === "success" ? <div className="bb-entry-state is-success" role="status"><CheckCircle2 /><div><b>Access confirmed</b><span>Welcome, {successTeam}. Opening your dashboard...</span></div></div> : <form onSubmit={handleSubmit} className="bb-entry-form">
        <label><span>Team number</span><div className="bb-field"><KeyRound size={18} /><input type="number" min="1" max="14" inputMode="numeric" autoComplete="off" value={teamNumber} onChange={event => { setTeamNumber(event.target.value); setEntryState("idle"); }} placeholder="01" required disabled={entryState === "loading"} /></div></label>
        <label><span>Team PIN</span><div className="bb-field"><LockKeyhole size={18} /><input type="password" inputMode="numeric" autoComplete="current-password" value={teamPin} onChange={event => { setTeamPin(event.target.value); setEntryState("idle"); }} placeholder="••••" minLength={4} maxLength={8} required disabled={entryState === "loading"} /></div></label>
        {entryState === "invalid" && <div className="bb-entry-state is-error" role="alert"><TriangleAlert /><div><b>We could not open that box.</b><span>Check your team number and PIN, then try again.</span></div></div>}
        <button className="bb-primary-action" disabled={entryState === "loading"} type="submit">{entryState === "loading" ? <><LoaderCircle className="animate-spin" size={18} /> Checking your credentials</> : <>Enter the Bazaar <span>→</span></>}</button>
      </form>}
      <div className="bb-entry-security"><ShieldCheck size={16} /><span>Your session is saved securely for this browser during the game.</span></div>
    </section>
    <p className="bb-entry-footer">CRACK IT. TRADE IT. BLUFF YOUR WAY TO THE TOP.</p>
  </main>;
}
