# Chroma Route-Link Update

The dashboard removes the `TEAM 01 / CODING CLUB RVCE` line and no longer places its primary welcome in a framed hero background panel.

The four redirect links use a ChromaGrid-inspired card grid: each card receives a colored border, a pointer-following spotlight, a muted surround effect, and a route-specific chromatic gradient. Cards route internally to My Cards, Bazaar, Leaderboard, and Rules without opening external links.

Route changes use a short, directional opacity and transform transition. The whole player canvas gains slow ambient radial-color movement rather than a static solid background. Motion respects reduced-motion preferences.
