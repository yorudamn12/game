# Supplied Interaction Update

The team-entry page begins with a rapid multilingual greeting animation that cycles through `Hello`, `こんにちは`, `Bonjour`, `Hola`, `안녕하세요`, `Ciao`, and `Hallo`, using a short vertical enter and exit transition before the form remains available.

Player navigation replaces the previous wheel interaction with a compact smooth tab bar. The active route uses a sliding indicator, and tabs remain keyboard accessible.

My Cards is reduced to essential card information only. Every puzzle card returns to a question-mark front. Tapping or clicking a card performs a 3D flip; the back displays only its visible input/output examples and final-input row, with no dialog, answer, explanation, or extra call to action.
