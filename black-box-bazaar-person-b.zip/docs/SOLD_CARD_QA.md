# Completed-Sale Ownership QA

The seller’s live My Cards view initially contained B2. After the buyer requested the seeded B2 listing and the seller confirmed it, the open My Cards session received the realtime update and removed B2 without a manual refresh. The reviewed capture shows only B1, B3, and B4.

The seller’s Bazaar capture retains the completed B2 transaction in **Recent history**, displaying its completed status and 35 BitBuck price. B2 no longer appears in the seller’s cards or active own-listings view.

In BAZAAR, each available non-listed card now presents both Solve and Sell controls. Solve remains visibly disabled until SUBMISSION and Sell remains enabled only in BAZAAR, preserving phase rules while making the available choices clear.

The reviewed BAZAAR capture shows all available Team 01 cards with both controls: muted disabled Solve and active Sell. The reviewed SUBMISSION capture shows the inverse for available cards, then confirms a submitted card displays `submitted / waiting for reveal` with no remaining action buttons while the success feedback does not reveal the correct answer.
