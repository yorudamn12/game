CREATE TABLE `cards` (
	`id` varchar(16) NOT NULL,
	`title` varchar(160) NOT NULL,
	`tier` enum('1','2','3') NOT NULL,
	`initialOwner` varchar(16) NOT NULL,
	`currentOwner` varchar(16) NOT NULL,
	`status` enum('owned','listed') NOT NULL DEFAULT 'owned',
	`pointsCorrect` int NOT NULL,
	`pointsWrong` int NOT NULL,
	`examplesJson` text NOT NULL,
	`finalInput` varchar(120) NOT NULL,
	`question` text NOT NULL,
	`answerKey` varchar(400),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `cards_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `gameState` (
	`id` varchar(32) NOT NULL,
	`phase` enum('REGISTRATION','BAZAAR','SUBMISSION','REVEAL','GAME OVER') NOT NULL DEFAULT 'REGISTRATION',
	`isActive` boolean NOT NULL DEFAULT true,
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `gameState_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `listings` (
	`id` varchar(40) NOT NULL,
	`cardId` varchar(16) NOT NULL,
	`sellerId` varchar(16) NOT NULL,
	`price` int NOT NULL,
	`status` enum('active','sold','cancelled') NOT NULL DEFAULT 'active',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `listings_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `submissions` (
	`id` varchar(64) NOT NULL,
	`cardId` varchar(16) NOT NULL,
	`teamId` varchar(16) NOT NULL,
	`answer` text NOT NULL,
	`confidence` enum('low','medium','high') NOT NULL DEFAULT 'medium',
	`status` enum('pending','correct','incorrect') NOT NULL DEFAULT 'pending',
	`submittedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `submissions_id` PRIMARY KEY(`id`),
	CONSTRAINT `submissions_card_team_unique` UNIQUE(`cardId`,`teamId`)
);
--> statement-breakpoint
CREATE TABLE `teams` (
	`id` varchar(16) NOT NULL,
	`teamNumber` int NOT NULL,
	`teamName` varchar(120) NOT NULL,
	`score` int NOT NULL DEFAULT 0,
	`bitBucks` int NOT NULL DEFAULT 100,
	`pinHash` varchar(128) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `teams_id` PRIMARY KEY(`id`),
	CONSTRAINT `teams_teamNumber_unique` UNIQUE(`teamNumber`)
);
--> statement-breakpoint
CREATE TABLE `trades` (
	`id` varchar(40) NOT NULL,
	`listingId` varchar(40) NOT NULL,
	`cardId` varchar(16) NOT NULL,
	`sellerId` varchar(16) NOT NULL,
	`buyerId` varchar(16) NOT NULL,
	`price` int NOT NULL,
	`sellerConfirmed` boolean NOT NULL DEFAULT false,
	`buyerConfirmed` boolean NOT NULL DEFAULT false,
	`status` enum('pending','completed','cancelled','rejected') NOT NULL DEFAULT 'pending',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`completedAt` timestamp,
	CONSTRAINT `trades_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE INDEX `cards_currentOwner_idx` ON `cards` (`currentOwner`);--> statement-breakpoint
CREATE INDEX `listings_status_idx` ON `listings` (`status`);--> statement-breakpoint
CREATE INDEX `trades_listing_idx` ON `trades` (`listingId`);--> statement-breakpoint
CREATE INDEX `trades_party_idx` ON `trades` (`sellerId`,`buyerId`);