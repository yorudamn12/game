import { boolean, index, int, mysqlEnum, mysqlTable, text, timestamp, uniqueIndex, varchar } from "drizzle-orm/mysql-core";
import { GAME_PHASES } from "../shared/game";

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export const teams = mysqlTable(
  "teams",
  {
    id: varchar("id", { length: 16 }).primaryKey(),
    teamNumber: int("teamNumber").notNull(),
    teamName: varchar("teamName", { length: 120 }).notNull(),
    score: int("score").notNull().default(0),
    bitBucks: int("bitBucks").notNull().default(100),
    pinHash: varchar("pinHash", { length: 128 }).notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => [uniqueIndex("teams_teamNumber_unique").on(table.teamNumber)],
);

export const cards = mysqlTable(
  "cards",
  {
    id: varchar("id", { length: 16 }).primaryKey(),
    title: varchar("title", { length: 160 }).notNull(),
    tier: mysqlEnum("tier", ["1", "2", "3"]).notNull(),
    initialOwner: varchar("initialOwner", { length: 16 }).notNull(),
    currentOwner: varchar("currentOwner", { length: 16 }).notNull(),
    status: mysqlEnum("status", ["owned", "listed"]).notNull().default("owned"),
    pointsCorrect: int("pointsCorrect").notNull(),
    pointsWrong: int("pointsWrong").notNull(),
    examplesJson: text("examplesJson").notNull(),
    finalInput: varchar("finalInput", { length: 120 }).notNull(),
    question: text("question").notNull(),
    answerKey: varchar("answerKey", { length: 400 }),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => [index("cards_currentOwner_idx").on(table.currentOwner)],
);

export const listings = mysqlTable(
  "listings",
  {
    id: varchar("id", { length: 40 }).primaryKey(),
    cardId: varchar("cardId", { length: 16 }).notNull(),
    sellerId: varchar("sellerId", { length: 16 }).notNull(),
    price: int("price").notNull(),
    status: mysqlEnum("status", ["active", "sold", "cancelled"]).notNull().default("active"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => [index("listings_status_idx").on(table.status)],
);

export const trades = mysqlTable(
  "trades",
  {
    id: varchar("id", { length: 40 }).primaryKey(),
    listingId: varchar("listingId", { length: 40 }).notNull(),
    cardId: varchar("cardId", { length: 16 }).notNull(),
    sellerId: varchar("sellerId", { length: 16 }).notNull(),
    buyerId: varchar("buyerId", { length: 16 }).notNull(),
    price: int("price").notNull(),
    sellerConfirmed: boolean("sellerConfirmed").notNull().default(false),
    buyerConfirmed: boolean("buyerConfirmed").notNull().default(false),
    status: mysqlEnum("status", ["pending", "completed", "cancelled", "rejected"]).notNull().default("pending"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    completedAt: timestamp("completedAt"),
  },
  table => [index("trades_listing_idx").on(table.listingId), index("trades_party_idx").on(table.sellerId, table.buyerId)],
);

export const submissions = mysqlTable(
  "submissions",
  {
    id: varchar("id", { length: 64 }).primaryKey(),
    cardId: varchar("cardId", { length: 16 }).notNull(),
    teamId: varchar("teamId", { length: 16 }).notNull(),
    answer: text("answer").notNull(),
    confidence: mysqlEnum("confidence", ["low", "medium", "high"]).notNull().default("medium"),
    status: mysqlEnum("status", ["pending", "correct", "incorrect"]).notNull().default("pending"),
    submittedAt: timestamp("submittedAt").defaultNow().notNull(),
  },
  table => [uniqueIndex("submissions_card_team_unique").on(table.cardId, table.teamId)],
);

export const gameState = mysqlTable("gameState", {
  id: varchar("id", { length: 32 }).primaryKey(),
  phase: mysqlEnum("phase", GAME_PHASES).notNull().default("REGISTRATION"),
  isActive: boolean("isActive").notNull().default(true),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

