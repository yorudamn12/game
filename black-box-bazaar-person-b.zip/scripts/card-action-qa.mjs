import { chromium } from "playwright-core";
import { mkdir } from "node:fs/promises";

const mode = process.env.QA_MODE || "bazaar";
const output = "/home/ubuntu/blackbox-ui-qa/card-actions";
await mkdir(output, { recursive: true });
const browser = await chromium.launch({ headless: true, executablePath: "/usr/bin/chromium", args: ["--no-sandbox"] });
const page = await browser.newPage({ viewport: { width: 390, height: 844 } });
await page.goto("http://localhost:3000/", { waitUntil: "domcontentloaded" });
await page.locator('input[type="number"]').fill("1");
await page.locator('input[type="password"]').fill("2026");
await page.getByRole("button", { name: /Enter the Bazaar/i }).click();
await page.waitForURL(/dashboard/, { timeout: 10000 });
await page.getByRole("tab", { name: "My Cards" }).click();
await page.waitForURL(/cards/, { timeout: 10000 });
await page.waitForTimeout(650);
const card = page.locator(".bb-simple-card").filter({ hasText: "available" }).first();
if (!await card.count()) throw new Error("No available card was found for card-action verification.");
const cardId = await card.locator(".bb-simple-card-meta b").innerText();
const stableCard = page.locator(`[data-manus-editable="card-${cardId}"]`);
const solve = card.getByRole("button", { name: "Solve" });
const sell = card.getByRole("button", { name: "Sell" });
if (mode === "bazaar") {
  if (!await solve.isDisabled() || await sell.isDisabled()) throw new Error("Expected disabled Solve and enabled Sell in BAZAAR.");
  await page.screenshot({ path: `${output}/bazaar-dual-actions.png`, fullPage: true });
} else {
  if (await solve.isDisabled() || !await sell.isDisabled()) throw new Error("Expected enabled Solve and disabled Sell in SUBMISSION.");
  console.log("solve-button", await solve.evaluate(button => button.outerHTML));
  await solve.click();
  await page.waitForTimeout(300);
  console.log("dialog-count", await page.locator('[role="dialog"]').count(), "content-count", await page.locator('[data-slot="dialog-content"]').count());
  await page.screenshot({ path: `${output}/submission-solve-dialog-debug.png`, fullPage: true });
  await page.locator("textarea").fill("QA final output");
  await page.getByRole("button", { name: /Review final submission/i }).click();
  await page.getByRole("button", { name: /Lock final answer/i }).click();
  await stableCard.getByText(/Submitted \/ waiting for reveal/i).waitFor({ state: "visible", timeout: 10000 });
  if (await stableCard.getByRole("button", { name: "Solve" }).count() || await stableCard.getByRole("button", { name: "Sell" }).count()) throw new Error("Submitted card still exposes Solve or Sell actions.");
  await page.screenshot({ path: `${output}/submission-locked.png`, fullPage: true });
}
console.log(`Card-action QA (${mode}): PASS`);
await browser.close();
