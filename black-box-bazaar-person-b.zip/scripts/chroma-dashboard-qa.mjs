import { chromium } from "playwright-core";
import { mkdir } from "node:fs/promises";

const output = "/home/ubuntu/blackbox-ui-qa/chroma-dashboard";
await mkdir(output, { recursive: true });
const browser = await chromium.launch({ headless: true, executablePath: "/usr/bin/chromium", args: ["--no-sandbox"] });

for (const viewport of [{ name: "mobile", width: 390, height: 844 }, { name: "desktop", width: 1280, height: 800 }]) {
  const page = await browser.newPage({ viewport: { width: viewport.width, height: viewport.height }, deviceScaleFactor: 1 });
  await page.goto("http://localhost:3000/", { waitUntil: "domcontentloaded" });
  await page.locator('input[type="number"]').fill("1");
  await page.locator('input[type="password"]').fill("2026");
  await page.getByRole("button", { name: /Enter the Bazaar/i }).click();
  await page.waitForURL(/dashboard/, { timeout: 10000 });
  await page.waitForTimeout(1400);
  if (await page.locator(".bb-hero-panel").count()) throw new Error("Legacy dashboard hero panel still exists.");
  if (await page.getByText(/TEAM 01\s*\/\s*CODING CLUB RVCE/i).count()) throw new Error("Removed team/coding-club label is still visible.");
  if (!await page.locator(".bb-ambient-canvas").isVisible()) throw new Error("Ambient canvas is missing.");
  const grid = page.locator(".bb-chroma-grid");
  await grid.hover({ position: { x: 45, y: 40 } });
  if (await grid.locator(".bb-chroma-route").count() !== 4) throw new Error("Expected four Chroma route links.");
  await page.screenshot({ path: `${output}/${viewport.name}-dashboard.png`, fullPage: true });
  await grid.getByRole("button", { name: /My Cards/i }).click();
  await page.waitForURL(/cards/, { timeout: 10000 });
  await page.waitForTimeout(350);
  if (!await page.locator(".bb-route-transition").isVisible()) throw new Error("Route transition wrapper is missing.");
  await page.screenshot({ path: `${output}/${viewport.name}-cards.png`, fullPage: true });
  await page.close();
}

console.log("Chroma dashboard and route-transition QA: PASS");
await browser.close();
