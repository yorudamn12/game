import { chromium } from "playwright-core";
import { mkdir } from "node:fs/promises";

const output = "/home/ubuntu/blackbox-ui-qa";
await mkdir(output, { recursive: true });
const browser = await chromium.launch({ headless: true, executablePath: "/usr/bin/chromium", args: ["--no-sandbox"] });
const page = await browser.newPage({ viewport: { width: 1280, height: 800 }, deviceScaleFactor: 1 });
await page.goto("http://localhost:3000/", { waitUntil: "networkidle" });
await page.locator('input[type="number"]').fill("14");
await page.locator('input[type="password"]').fill("2026");
await page.getByRole("button", { name: /Enter the Bazaar/i }).click();
await page.waitForURL(/dashboard/, { timeout: 10000 });
await page.goto("http://localhost:3000/cards", { waitUntil: "networkidle" });
await page.waitForSelector(".bb-card-sell:not([disabled])", { timeout: 10000 });
await page.locator(".bb-card-sell:not([disabled])").first().click();
await page.locator('input[type="number"]').last().fill("91");
await page.getByRole("button", { name: /List for sale/i }).click();
await page.waitForSelector('[role="dialog"]', { state: "hidden", timeout: 10000 });
await page.waitForSelector(".bb-card-state.is-listed", { timeout: 10000 });
await page.screenshot({ path: `${output}/desktop-my-cards-listed.png`, fullPage: true });
await page.goto("http://localhost:3000/dashboard", { waitUntil: "networkidle" });
await page.waitForSelector(".bb-dashboard-listings", { timeout: 10000 });
await page.screenshot({ path: `${output}/desktop-dashboard-listed.png`, fullPage: true });
await page.goto("http://localhost:3000/bazaar", { waitUntil: "networkidle" });
await page.waitForSelector(".bb-bazaar-tools", { timeout: 10000 });
const bazaarListingText = await page.locator(".bb-own-listings").innerText();
if (!bazaarListingText.includes("Black Box N1") || !bazaarListingText.includes("91")) throw new Error("The new N1 91-BitBuck listing did not propagate to Bazaar.");
await page.screenshot({ path: `${output}/desktop-bazaar.png`, fullPage: true });
for (const [route, filename, selector] of [["/leaderboard", "desktop-leaderboard.png", ".bb-leaderboard-card"], ["/rules", "desktop-rules.png", ".bb-rules-objective"]]) {
  await page.goto(`http://localhost:3000${route}`, { waitUntil: "networkidle" });
  await page.waitForSelector(selector, { timeout: 10000 });
  await page.screenshot({ path: `${output}/${filename}`, fullPage: true });
}
console.log("Desktop listing-propagation QA: PASS");
await browser.close();
