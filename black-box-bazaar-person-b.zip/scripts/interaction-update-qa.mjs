import { chromium } from "playwright-core";
import { mkdir } from "node:fs/promises";

const output = "/home/ubuntu/blackbox-ui-qa/interaction-update";
await mkdir(output, { recursive: true });
const browser = await chromium.launch({ headless: true, executablePath: "/usr/bin/chromium", args: ["--no-sandbox"] });

for (const viewport of [{ name: "mobile", width: 390, height: 844 }, { name: "desktop", width: 1280, height: 800 }]) {
  const page = await browser.newPage({ viewport: { width: viewport.width, height: viewport.height }, deviceScaleFactor: 1 });
  await page.goto("http://localhost:3000/", { waitUntil: "domcontentloaded" });
  await page.waitForSelector(".bb-dynamic-greeting", { timeout: 10000 });
  await page.screenshot({ path: `${output}/${viewport.name}-entry.png`, fullPage: true });
  await page.locator('input[type="number"]').fill("1");
  await page.locator('input[type="password"]').fill("2026");
  await page.getByRole("button", { name: /Enter the Bazaar/i }).click();
  await page.waitForURL(/dashboard/, { timeout: 10000 });
  if (await page.locator(".option-wheel").count()) throw new Error("Old OptionWheel navigation is still present.");
  const navigation = page.locator(viewport.name === "mobile" ? ".bb-bottom-nav .bb-smooth-tabs" : ".bb-desktop-tabs .bb-smooth-tabs");
  await navigation.getByRole("tab", { name: "My Cards" }).click();
  await page.waitForURL(/cards/, { timeout: 10000 });
  const card = page.locator(".bb-flip-card").first();
  await card.click();
  await page.waitForTimeout(600);
  if (!await card.locator(".bb-flip-table").isVisible()) throw new Error("Flipped card did not reveal its input/output table.");
  await page.screenshot({ path: `${output}/${viewport.name}-cards-flipped.png`, fullPage: true });
  await page.close();
}

console.log("Greeting, smooth-tab, and card-flip QA: PASS");
await browser.close();
