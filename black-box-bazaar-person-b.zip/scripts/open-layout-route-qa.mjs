import { chromium } from "playwright-core";
import { mkdir } from "node:fs/promises";

const output = "/home/ubuntu/blackbox-ui-qa/open-layout";
await mkdir(output, { recursive: true });
const routes = [
  ["dashboard", "/dashboard", ".bb-hero-panel"],
  ["cards", "/cards", ".bb-card-grid"],
  ["bazaar", "/bazaar", ".bb-bazaar-tools"],
  ["leaderboard", "/leaderboard", ".bb-leaderboard-card"],
  ["rules", "/rules", ".bb-rules-objective"],
];
const browser = await chromium.launch({ headless: true, executablePath: "/usr/bin/chromium", args: ["--no-sandbox"] });
for (const viewport of [{ name: "mobile", width: 390, height: 844 }, { name: "desktop", width: 1280, height: 800 }]) {
  const page = await browser.newPage({ viewport: { width: viewport.width, height: viewport.height }, deviceScaleFactor: 1 });
  await page.goto("http://localhost:3000/", { waitUntil: "domcontentloaded" });
  await page.locator('input[type="number"]').fill("1");
  await page.locator('input[type="password"]').fill("2026");
  await page.getByRole("button", { name: /Enter the Bazaar/i }).click();
  await page.waitForURL(/dashboard/, { timeout: 10000 });
  for (const [name, route, selector] of routes) {
    await page.goto(`http://localhost:3000${route}`, { waitUntil: "domcontentloaded" });
    await page.waitForSelector(selector, { timeout: 10000 });
    const editableCount = await page.locator("[data-manus-editable]").count();
    if (editableCount < 1) throw new Error(`${name} does not expose an editor-friendly content target.`);
    await page.screenshot({ path: `${output}/${viewport.name}-${name}.png`, fullPage: true });
  }
  await page.close();
}
console.log("Open-canvas route and editor-target QA: PASS");
await browser.close();
