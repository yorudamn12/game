import { chromium } from "playwright-core";
import { mkdir } from "node:fs/promises";

const output = "/home/ubuntu/blackbox-ui-qa/sold-card-history";
await mkdir(output, { recursive: true });
const browser = await chromium.launch({ headless: true, executablePath: "/usr/bin/chromium", args: ["--no-sandbox"] });

async function login(page, teamNumber) {
  await page.goto("http://localhost:3000/", { waitUntil: "domcontentloaded" });
  await page.locator('input[type="number"]').fill(String(teamNumber));
  await page.locator('input[type="password"]').fill("2026");
  await page.getByRole("button", { name: /Enter the Bazaar/i }).click();
  await page.waitForURL(/dashboard/, { timeout: 10000 });
}

const buyer = await browser.newPage({ viewport: { width: 390, height: 844 } });
const seller = await browser.newPage({ viewport: { width: 390, height: 844 } });
const sellerCards = await browser.newPage({ viewport: { width: 390, height: 844 } });
await login(buyer, 3);
await buyer.getByRole("tab", { name: "Bazaar" }).click();
await buyer.waitForURL(/bazaar/, { timeout: 10000 });
const listing = buyer.locator(".bb-listing-card", { hasText: "B2" }).first();
await listing.getByRole("button", { name: /Review purchase/i }).click();
await buyer.getByRole("button", { name: /Confirm purchase request/i }).click();
await buyer.waitForTimeout(300);

await login(seller, 2);
await seller.getByRole("tab", { name: "Bazaar" }).click();
await seller.waitForURL(/bazaar/, { timeout: 10000 });
await login(sellerCards, 2);
await sellerCards.getByRole("tab", { name: "My Cards" }).click();
await sellerCards.waitForURL(/cards/, { timeout: 10000 });
await sellerCards.waitForSelector(".bb-simple-card", { timeout: 10000 });
if (!await sellerCards.locator(".bb-simple-card", { hasText: "B2" }).count()) throw new Error("B2 was not visible in the seller My Cards before completing the sale.");
await seller.locator(".bb-trade-row", { hasText: "B2" }).getByRole("button", { name: /Confirm/i }).click();
await sellerCards.waitForFunction(() => ![...document.querySelectorAll(".bb-simple-card")].some(card => card.textContent?.includes("B2")), undefined, { timeout: 10000 });
await sellerCards.screenshot({ path: `${output}/seller-cards-after-sale.png`, fullPage: true });
await seller.getByRole("tab", { name: "Bazaar" }).click();
await seller.waitForURL(/bazaar/, { timeout: 10000 });
const history = seller.locator(".bb-trade-history", { hasText: "B2" });
if (!await history.isVisible() || !await history.getByText("completed", { exact: true }).isVisible()) throw new Error("Completed B2 sale was not retained in Recent history.");
await seller.screenshot({ path: `${output}/seller-history-after-sale.png`, fullPage: true });
console.log("Sold-card ownership removal and trade-history QA: PASS");
await browser.close();
