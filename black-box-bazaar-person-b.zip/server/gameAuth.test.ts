import { describe, expect, it } from "vitest";
import { createPlayerSession, getPlayerTeamId, hashTeamPin } from "./gameAuth";

describe("player game authentication", () => {
  it("creates a refresh-safe signed session tied to exactly one team", async () => {
    const session = await createPlayerSession("TEAM-01");
    await expect(getPlayerTeamId(session)).resolves.toBe("TEAM-01");
  });

  it("rejects malformed or tampered player sessions", async () => {
    await expect(getPlayerTeamId("not-a-session-token")).resolves.toBeNull();
  });

  it("hashes team credentials deterministically without retaining the PIN", () => {
    expect(hashTeamPin(1, "2026")).toBe(hashTeamPin(1, "2026"));
    expect(hashTeamPin(1, "2026")).not.toBe(hashTeamPin(2, "2026"));
    expect(hashTeamPin(1, "2026")).not.toContain("2026");
  });
});

