import { createHash } from "node:crypto";
import { jwtVerify, SignJWT } from "jose";

const encoder = new TextEncoder();

function sessionSecret() {
  return encoder.encode(process.env.JWT_SECRET || "black-box-bazaar-development-session-secret");
}

export function hashTeamPin(teamNumber: number, pin: string) {
  const salt = process.env.BLACKBOX_PIN_SALT || "black-box-bazaar-development-pin-salt";
  return createHash("sha256").update(`${salt}:${teamNumber}:${pin}`).digest("hex");
}

export async function createPlayerSession(teamId: string) {
  return new SignJWT({ teamId, type: "player" })
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setExpirationTime("12h")
    .sign(sessionSecret());
}

export async function getPlayerTeamId(sessionToken: string) {
  try {
    const { payload } = await jwtVerify(sessionToken, sessionSecret());
    if (payload.type !== "player" || typeof payload.teamId !== "string") return null;
    return payload.teamId;
  } catch {
    return null;
  }
}

