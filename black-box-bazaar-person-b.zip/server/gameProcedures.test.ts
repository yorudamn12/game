import { beforeEach, describe, expect, it, vi } from "vitest";

const state = vi.hoisted(() => ({ db: null as any, phase: "BAZAAR" as string }));

vi.mock("./db", () => ({ getDb: vi.fn(async () => state.db) }));
vi.mock("./gameSeed", () => ({
  ensureGameSeed: vi.fn(async () => undefined),
  readGameState: vi.fn(async () => ({ phase: state.phase, isActive: true, updatedAt: new Date() })),
}));

import { appRouter } from "./routers";
import { createPlayerSession, hashTeamPin } from "./gameAuth";

type Mutation = { kind: "insert" | "update"; values?: unknown; where?: unknown };

function createDatabase(selectResponses: unknown[][]) {
  const responses = [...selectResponses];
  const mutations: Mutation[] = [];
  const builder = (value: unknown[] = []) => {
    const chain: any = {
      from: () => chain,
      where: (where: unknown) => { chain.whereValue = where; return chain; },
      orderBy: () => Promise.resolve(value),
      limit: () => Promise.resolve(value),
      then: (resolve: (data: unknown[]) => unknown, reject: (error: unknown) => unknown) => Promise.resolve(value).then(resolve, reject),
    };
    return chain;
  };
  const mutation = (kind: Mutation["kind"]) => {
    const record: Mutation = { kind };
    mutations.push(record);
    const chain: any = {
      set: (values: unknown) => { record.values = values; return chain; },
      values: (values: unknown) => { record.values = values; return Promise.resolve(); },
      where: (where: unknown) => { record.where = where; return Promise.resolve(); },
    };
    return chain;
  };
  const db: any = {
    select: () => builder((responses.shift() || []) as unknown[]),
    insert: () => mutation("insert"),
    update: () => mutation("update"),
    transaction: async (callback: (tx: any) => unknown) => callback(db),
  };
  return { db, mutations };
}

function caller() {
  return appRouter.createCaller({ user: null, req: {} as any, res: {} as any });
}

let session = "";
let sellerSession = "";

describe("game player procedures", () => {
  beforeEach(async () => { state.phase = "BAZAAR"; session = await createPlayerSession("TEAM-01"); sellerSession = await createPlayerSession("TEAM-02"); });

  it("authenticates a valid team and safely rejects an invalid PIN", async () => {
    const team = { id: "TEAM-01", teamNumber: 1, teamName: "Team 01", score: 0, bitBucks: 100, pinHash: hashTeamPin(1, "2026") };
    const valid = createDatabase([[team], [team], []]);
    state.db = valid.db;
    const result = await caller().game.login({ teamNumber: 1, teamPin: "2026" });
    expect(result.team.teamName).toBe("Team 01");
    expect(result.cards).toEqual([]);

    const invalid = createDatabase([[team]]);
    state.db = invalid.db;
    await expect(caller().game.login({ teamNumber: 1, teamPin: "0000" })).rejects.toMatchObject({ message: "Invalid team credentials." });
  });

  it("creates a listing for a current owner during BAZAAR", async () => {
    const fake = createDatabase([[{ id: "A1", currentOwner: "TEAM-01", status: "owned" }]]);
    state.db = fake.db;
    const result = await caller().game.createListing({ sessionToken: session, cardId: "A1", price: 25 });
    expect(result.success).toBe(true);
    expect(fake.mutations.map(mutation => mutation.kind)).toEqual(["update", "insert"]);
  });

  it("creates a pending purchase request only for an affordable active listing", async () => {
    const fake = createDatabase([[{ id: "LIST-B2", sellerId: "TEAM-02", cardId: "B2", price: 35, status: "active" }], [{ id: "TEAM-01", bitBucks: 100 }], []]);
    state.db = fake.db;
    const result = await caller().game.requestPurchase({ sessionToken: session, listingId: "LIST-B2" });
    expect(result.status).toBe("pending");
    expect(fake.mutations[0]?.kind).toBe("insert");
  });

  it("confirms the seller side and completes an atomic trade once both confirmations exist", async () => {
    const trade = { id: "TRADE-1", sellerId: "TEAM-02", buyerId: "TEAM-01", cardId: "B2", listingId: "LIST-B2", price: 35, sellerConfirmed: false, buyerConfirmed: true, status: "pending" };
    const fake = createDatabase([[trade], [{ id: "TEAM-02", bitBucks: 100 }], [{ id: "TEAM-01", bitBucks: 100 }], [{ id: "B2", currentOwner: "TEAM-02" }], [{ id: "LIST-B2", status: "active" }]]);
    state.db = fake.db;
    const result = await caller().game.confirmTrade({ sessionToken: sellerSession, tradeId: "TRADE-1" });
    expect(result.status).toBe("completed");
    expect(fake.mutations.filter(mutation => mutation.kind === "update")).toHaveLength(5);
  });

  it("cancels and rejects pending trades without a card or BitBuck transfer", async () => {
    const cancelDb = createDatabase([[{ id: "TRADE-2", sellerId: "TEAM-02", buyerId: "TEAM-01", status: "pending" }]]);
    state.db = cancelDb.db;
    await expect(caller().game.cancelTrade({ sessionToken: session, tradeId: "TRADE-2" })).resolves.toMatchObject({ status: "cancelled" });
    expect(cancelDb.mutations).toHaveLength(1);

    const rejectDb = createDatabase([[{ id: "TRADE-3", sellerId: "TEAM-02", buyerId: "TEAM-01", status: "pending" }]]);
    state.db = rejectDb.db;
    await expect(caller().game.rejectTrade({ sessionToken: sellerSession, tradeId: "TRADE-3" })).resolves.toMatchObject({ status: "rejected" });
    expect(rejectDb.mutations).toHaveLength(1);
  });

  it("stores a final submission only during SUBMISSION without returning any answer key", async () => {
    state.phase = "SUBMISSION";
    const fake = createDatabase([[{ id: "A1", currentOwner: "TEAM-01" }], []]);
    state.db = fake.db;
    const result = await caller().game.submitAnswer({ sessionToken: session, cardId: "A1", answer: "55", confidence: "high" });
    expect(result).toEqual({ status: "pending", message: "Your answer is locked and will remain hidden until the reveal." });
    expect(JSON.stringify(result)).not.toContain("55");
  });
});
