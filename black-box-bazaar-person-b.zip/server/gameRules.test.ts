import { describe, expect, it } from "vitest";
import { derivePlayerCardState, getActionUnavailableMessage, isPlayerActionAllowed } from "../shared/game";

describe("Black Box Bazaar player phase rules", () => {
  it("opens listing, buying, and confirmation together only in BAZAAR", () => {
    (["list", "buy", "confirmTrade"] as const).forEach(action => {
      expect(isPlayerActionAllowed("BAZAAR", action)).toBe(true);
      expect(isPlayerActionAllowed("REGISTRATION", action)).toBe(false);
      expect(isPlayerActionAllowed("REVEAL", action)).toBe(false);
      expect(isPlayerActionAllowed("GAME OVER", action)).toBe(false);
    });
  });

  it("allows trading only during BAZAAR", () => {
    expect(isPlayerActionAllowed("BAZAAR", "buy")).toBe(true);
    expect(isPlayerActionAllowed("SUBMISSION", "buy")).toBe(false);
    expect(getActionUnavailableMessage("SUBMISSION", "buy")).toContain("BAZAAR");
  });

  it("allows answers only during SUBMISSION", () => {
    expect(isPlayerActionAllowed("SUBMISSION", "submit")).toBe(true);
    expect(isPlayerActionAllowed("REVEAL", "submit")).toBe(false);
    expect(getActionUnavailableMessage("REVEAL", "submit")).toContain("REVEAL");
  });

  it("derives the required player card states without exposing sold cards as owned", () => {
    expect(derivePlayerCardState("owned", false)).toBe("available");
    expect(derivePlayerCardState("listed", false)).toBe("listed");
    expect(derivePlayerCardState("owned", true)).toBe("submitted");
  });
});
