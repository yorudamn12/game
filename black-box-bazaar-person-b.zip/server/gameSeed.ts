import { eq } from "drizzle-orm";
import { cards, gameState, listings, teams } from "../drizzle/schema";
import { hashTeamPin } from "./gameAuth";

const defaultPin = process.env.BLACKBOX_SEED_PIN || "2026";

const sampleCards: Record<string, { title: string; tier: "1" | "2" | "3"; examples: Array<{ input: string; output: string }>; finalInput: string }> = {
  A1: {
    title: "Next in Line",
    tier: "1",
    examples: [
      { input: "10", output: "11" },
      { input: "24", output: "29" },
      { input: "30", output: "31" },
    ],
    finalInput: "54",
  },
  A2: {
    title: "Hidden Decoder",
    tier: "2",
    examples: [
      { input: "23", output: "15" },
      { input: "47", output: "41" },
      { input: "91", output: "90" },
    ],
    finalInput: "74",
  },
  A3: {
    title: "Signal Shift",
    tier: "3",
    examples: [
      { input: "112233", output: "22200000" },
      { input: "1000000", output: "610000000" },
      { input: "999999", output: "6" },
    ],
    finalInput: "555000",
  },
  A4: {
    title: "Signal Shift II",
    tier: "3",
    examples: [
      { input: "112233", output: "22200000" },
      { input: "1000000", output: "610000000" },
      { input: "999999", output: "6" },
    ],
    finalInput: "555000",
  },
};

function genericCard(cardId: string, tier: "1" | "2" | "3") {
  return {
    title: `Black Box ${cardId}`,
    tier,
    examples: [] as Array<{ input: string; output: string }>,
    finalInput: "See physical card",
  };
}

export async function ensureGameSeed(db: any) {
  const existing = await db.select({ id: teams.id }).from(teams).limit(1);
  if (existing.length > 0) return;

  const teamRows = Array.from({ length: 14 }, (_, index) => {
    const teamNumber = index + 1;
    return {
      id: `TEAM-${String(teamNumber).padStart(2, "0")}`,
      teamNumber,
      teamName: `Team ${String(teamNumber).padStart(2, "0")}`,
      score: 0,
      bitBucks: 100,
      pinHash: hashTeamPin(teamNumber, defaultPin),
    };
  });
  await db.insert(teams).values(teamRows);

  const cardRows = teamRows.flatMap((team, teamIndex) => {
    const letter = String.fromCharCode(65 + teamIndex);
    return [1, 2, 3, 4].map((number) => {
      const cardId = `${letter}${number}`;
      const fallbackTier = number === 1 ? "1" : number === 2 ? "2" : "3";
      const puzzle = sampleCards[cardId] || genericCard(cardId, fallbackTier);
      return {
        id: cardId,
        title: puzzle.title,
        tier: puzzle.tier,
        initialOwner: team.id,
        currentOwner: team.id,
        status: cardId === "B2" ? ("listed" as const) : ("owned" as const),
        pointsCorrect: 10,
        pointsWrong: puzzle.tier === "1" ? -1 : puzzle.tier === "2" ? -2 : -5,
        examplesJson: JSON.stringify(puzzle.examples),
        finalInput: puzzle.finalInput,
        question: "Study the input and output pairs on the card, identify the hidden rule, then determine the final output.",
        answerKey: null,
      };
    });
  });
  await db.insert(cards).values(cardRows);
  await db.insert(listings).values({
    id: "LIST-B2",
    cardId: "B2",
    sellerId: "TEAM-02",
    price: 35,
    status: "active",
  });
  await db.insert(gameState).values({ id: "main", phase: "BAZAAR", isActive: true });
}

export async function readGameState(db: any) {
  await ensureGameSeed(db);
  const [state] = await db.select().from(gameState).where(eq(gameState.id, "main")).limit(1);
  return state;
}
