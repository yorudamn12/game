import type { Express } from "express";
import { EventEmitter } from "node:events";

const events = new EventEmitter();

/** Broadcasts only an invalidation signal. No player or protected game data is sent over this channel. */
export function publishGameUpdate() {
  events.emit("game:update");
}

export function registerLiveUpdates(app: Express) {
  app.get("/api/game-events", (_req, res) => {
    res.setHeader("Content-Type", "text/event-stream");
    res.setHeader("Cache-Control", "no-cache, no-transform");
    res.setHeader("Connection", "keep-alive");
    res.flushHeaders();
    res.write("event: connected\ndata: ready\n\n");

    const onUpdate = () => res.write("event: game:update\ndata: refresh\n\n");
    const heartbeat = setInterval(() => res.write(": keepalive\n\n"), 25000);
    events.on("game:update", onUpdate);

    _req.on("close", () => {
      clearInterval(heartbeat);
      events.off("game:update", onUpdate);
      res.end();
    });
  });
}

