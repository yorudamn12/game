import { describe, expect, it } from "vitest";
import { derivePlayerCardState, getActionUnavailableMessage, isPlayerActionAllowed } from "../shared/game";
import { createPlayerSession, getPlayerTeamId, hashTeamPin } from "./gameAuth";

describe("player game procedure outcomes", () => {
  it("models login success and a generic credential failure without exposing credential internals", async () => {
    const storedHash = hashTeamPin(1, "2026");
    expect(storedHash).toBe(hashTeamPin(1, "2026"));
    expect(storedHash).not.toBe(hashTeamPin(1, "0000"));
    const session = await createPlayerSession("TEAM-01");
    await expect(getPlayerTeamId(session)).resolves.toBe("TEAM-01");
  });

  it("allows listing and purchase requests only during BAZAAR", () => {
    expect(isPlayerActionAllowed("BAZAAR", "list")).toBe(true);
    expect(isPlayerActionAllowed("BAZAAR", "buy")).toBe(true);
    expect(isPlayerActionAllowed("SUBMISSION", "list")).toBe(false);
    expect(getActionUnavailableMessage("SUBMISSION", "buy")).toContain("BAZAAR");
  });

  it("requires both buyer and seller confirmations before a trade may complete", () => {
    const buyerConfirmed = true;
    const sellerConfirmed = false;
    expect(buyerConfirmed && sellerConfirmed).toBe(false);
    expect(buyerConfirmed && true).toBe(true);
  });

  it("represents cancelled and rejected trades as terminal non-transfer outcomes", () => {
    const terminalWithoutTransfer = new Set(["cancelled", "rejected"]);
    expect(terminalWithoutTransfer.has("cancelled")).toBe(true);
    expect(terminalWithoutTransfer.has("rejected")).toBe(true);
    expect(terminalWithoutTransfer.has("pending")).toBe(false);
  });

  it("opens answer submission only in SUBMISSION and maps a locked answer to submitted", () => {
    expect(isPlayerActionAllowed("SUBMISSION", "submit")).toBe(true);
    expect(isPlayerActionAllowed("REVEAL", "submit")).toBe(false);
    expect(derivePlayerCardState("owned", true)).toBe("submitted");
  });
});

