import { and, asc, desc, eq, inArray } from "drizzle-orm";
import { nanoid } from "nanoid";
import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { cards, gameState, listings, submissions, teams, trades } from "../drizzle/schema";
import { derivePlayerCardState, getActionUnavailableMessage, isPlayerActionAllowed, type GamePhase } from "../shared/game";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { COOKIE_NAME } from "@shared/const";
import { publicProcedure, router } from "./_core/trpc";
import { getDb } from "./db";
import { createPlayerSession, getPlayerTeamId, hashTeamPin } from "./gameAuth";
import { ensureGameSeed, readGameState } from "./gameSeed";
import { publishGameUpdate } from "./liveUpdates";

const sessionInput = z.object({ sessionToken: z.string().min(20) });

function safeExamples(value: string) {
  try {
    const parsed = JSON.parse(value);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

async function database() {
  const db = await getDb();
  if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "The game service is temporarily unavailable." });
  await ensureGameSeed(db);
  return db;
}

async function requireTeam(sessionToken: string) {
  const teamId = await getPlayerTeamId(sessionToken);
  if (!teamId) throw new TRPCError({ code: "UNAUTHORIZED", message: "Your session has expired. Please enter your team credentials again." });
  return teamId;
}

async function requirePhase(db: any, action: "list" | "buy" | "confirmTrade" | "submit") {
  const state = await readGameState(db);
  const phase = state.phase as GamePhase;
  if (!isPlayerActionAllowed(phase, action)) {
    throw new TRPCError({ code: "PRECONDITION_FAILED", message: getActionUnavailableMessage(phase, action) || "This action is unavailable." });
  }
  return state;
}

async function playerSnapshot(db: any, teamId: string) {
  const [team] = await db.select({ id: teams.id, teamNumber: teams.teamNumber, teamName: teams.teamName, score: teams.score, bitBucks: teams.bitBucks }).from(teams).where(eq(teams.id, teamId)).limit(1);
  if (!team) throw new TRPCError({ code: "UNAUTHORIZED", message: "Your team session is no longer available." });
  const ownedCards = await db.select().from(cards).where(eq(cards.currentOwner, teamId)).orderBy(asc(cards.id));
  const cardModels = await Promise.all(ownedCards.map(async (card: any) => {
    const [submission] = await db.select({ id: submissions.id, status: submissions.status, confidence: submissions.confidence, submittedAt: submissions.submittedAt }).from(submissions).where(and(eq(submissions.cardId, card.id), eq(submissions.teamId, teamId))).limit(1);
    const [listing] = await db.select({ id: listings.id, price: listings.price, status: listings.status }).from(listings).where(and(eq(listings.cardId, card.id), eq(listings.status, "active"))).limit(1);
    return {
      id: card.id,
      title: card.title,
      tier: card.tier,
      status: derivePlayerCardState(card.status, Boolean(submission)),
      pointsCorrect: card.pointsCorrect,
      pointsWrong: card.pointsWrong,
      examples: safeExamples(card.examplesJson),
      finalInput: card.finalInput,
      question: card.question,
      submission: submission || null,
      listing: listing || null,
    };
  }));
  const state = await readGameState(db);
  return { team, cards: cardModels, game: { phase: state.phase as GamePhase, isActive: state.isActive, updatedAt: state.updatedAt } };
}

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  game: router({
    login: publicProcedure.input(z.object({ teamNumber: z.coerce.number().int().min(1).max(14), teamPin: z.string().regex(/^\d{4,8}$/) })).mutation(async ({ input }) => {
      const db = await database();
      const [team] = await db.select().from(teams).where(eq(teams.teamNumber, input.teamNumber)).limit(1);
      if (!team || team.pinHash !== hashTeamPin(input.teamNumber, input.teamPin)) {
        throw new TRPCError({ code: "UNAUTHORIZED", message: "Invalid team credentials." });
      }
      const sessionToken = await createPlayerSession(team.id);
      const snapshot = await playerSnapshot(db, team.id);
      return { sessionToken, ...snapshot };
    }),
    dashboard: publicProcedure.input(sessionInput).query(async ({ input }) => {
      const db = await database();
      return playerSnapshot(db, await requireTeam(input.sessionToken));
    }),
    marketplace: publicProcedure.input(sessionInput).query(async ({ input }) => {
      const db = await database();
      const teamId = await requireTeam(input.sessionToken);
      const activeListings = await db.select().from(listings).where(eq(listings.status, "active")).orderBy(desc(listings.createdAt));
      const listedCards = activeListings.length ? await db.select({ id: cards.id, title: cards.title, tier: cards.tier }).from(cards).where(inArray(cards.id, activeListings.map((listing: any) => listing.cardId))) : [];
      const sellers = activeListings.length ? await db.select({ id: teams.id, teamName: teams.teamName, teamNumber: teams.teamNumber }).from(teams).where(inArray(teams.id, activeListings.map((listing: any) => listing.sellerId))) : [];
      const cardById = new Map(listedCards.map((card: any) => [card.id, card]));
      const sellerById = new Map(sellers.map((seller: any) => [seller.id, seller]));
      const teamTrades = await db.select().from(trades).where(and(inArray(trades.status, ["pending", "completed", "cancelled", "rejected"]), inArray(trades.sellerId, [teamId]))).orderBy(desc(trades.createdAt));
      const boughtTrades = await db.select().from(trades).where(and(inArray(trades.status, ["pending", "completed", "cancelled", "rejected"]), eq(trades.buyerId, teamId))).orderBy(desc(trades.createdAt));
      const combinedTrades = [...teamTrades, ...boughtTrades].filter((trade, index, all) => all.findIndex(candidate => candidate.id === trade.id) === index);
      return {
        listings: activeListings.map((listing: any) => ({ ...listing, card: cardById.get(listing.cardId), seller: sellerById.get(listing.sellerId), isOwnListing: listing.sellerId === teamId })),
        trades: combinedTrades,
      };
    }),
    leaderboard: publicProcedure.query(async () => {
      const db = await database();
      const rows = await db.select({ teamId: teams.id, teamName: teams.teamName, teamNumber: teams.teamNumber, score: teams.score, bitBucks: teams.bitBucks }).from(teams).orderBy(desc(teams.score), desc(teams.bitBucks));
      return rows.map((row: any, index: number) => ({ rank: index + 1, ...row }));
    }),
    createListing: publicProcedure.input(sessionInput.extend({ cardId: z.string().min(2).max(16), price: z.coerce.number().int().min(1).max(1000) })).mutation(async ({ input }) => {
      const db = await database();
      const teamId = await requireTeam(input.sessionToken);
      await requirePhase(db, "list");
      const [card] = await db.select().from(cards).where(eq(cards.id, input.cardId)).limit(1);
      if (!card || card.currentOwner !== teamId) throw new TRPCError({ code: "FORBIDDEN", message: "Only the current owner can list this card." });
      if (card.status === "listed") throw new TRPCError({ code: "CONFLICT", message: "This card already has an active listing." });
      const listingId = `LIST-${nanoid(10)}`;
      await db.transaction(async (tx: any) => {
        await tx.update(cards).set({ status: "listed" }).where(eq(cards.id, input.cardId));
        await tx.insert(listings).values({ id: listingId, cardId: input.cardId, sellerId: teamId, price: input.price, status: "active" });
      });
      publishGameUpdate();
      return { id: listingId, success: true };
    }),
    requestPurchase: publicProcedure.input(sessionInput.extend({ listingId: z.string().min(1) })).mutation(async ({ input }) => {
      const db = await database();
      const teamId = await requireTeam(input.sessionToken);
      await requirePhase(db, "buy");
      const [listing] = await db.select().from(listings).where(eq(listings.id, input.listingId)).limit(1);
      if (!listing || listing.status !== "active") throw new TRPCError({ code: "NOT_FOUND", message: "This listing is no longer active." });
      if (listing.sellerId === teamId) throw new TRPCError({ code: "FORBIDDEN", message: "You cannot purchase your own listing." });
      const [buyer] = await db.select().from(teams).where(eq(teams.id, teamId)).limit(1);
      if (!buyer || buyer.bitBucks < listing.price) throw new TRPCError({ code: "PRECONDITION_FAILED", message: "You do not have enough BitBucks for this card." });
      const [existingTrade] = await db.select().from(trades).where(and(eq(trades.listingId, listing.id), eq(trades.status, "pending"))).limit(1);
      if (existingTrade) throw new TRPCError({ code: "CONFLICT", message: "This listing is already awaiting a confirmation." });
      const tradeId = `TRADE-${nanoid(10)}`;
      await db.insert(trades).values({ id: tradeId, listingId: listing.id, cardId: listing.cardId, sellerId: listing.sellerId, buyerId: teamId, price: listing.price, buyerConfirmed: true, sellerConfirmed: false, status: "pending" });
      publishGameUpdate();
      return { id: tradeId, status: "pending" as const };
    }),
    confirmTrade: publicProcedure.input(sessionInput.extend({ tradeId: z.string().min(1) })).mutation(async ({ input }) => {
      const db = await database();
      const teamId = await requireTeam(input.sessionToken);
      await requirePhase(db, "confirmTrade");
      let finalStatus: "pending" | "completed" = "pending";
      await db.transaction(async (tx: any) => {
        const [trade] = await tx.select().from(trades).where(eq(trades.id, input.tradeId)).limit(1);
        if (!trade || trade.status !== "pending") throw new TRPCError({ code: "NOT_FOUND", message: "This trade is no longer awaiting confirmation." });
        if (teamId !== trade.sellerId && teamId !== trade.buyerId) throw new TRPCError({ code: "FORBIDDEN", message: "Only a trade participant can confirm this trade." });
        const nextSellerConfirmed = teamId === trade.sellerId ? true : trade.sellerConfirmed;
        const nextBuyerConfirmed = teamId === trade.buyerId ? true : trade.buyerConfirmed;
        if (!(nextSellerConfirmed && nextBuyerConfirmed)) {
          await tx.update(trades).set({ sellerConfirmed: nextSellerConfirmed, buyerConfirmed: nextBuyerConfirmed }).where(eq(trades.id, trade.id));
          return;
        }
        const [seller] = await tx.select().from(teams).where(eq(teams.id, trade.sellerId)).limit(1);
        const [buyer] = await tx.select().from(teams).where(eq(teams.id, trade.buyerId)).limit(1);
        const [card] = await tx.select().from(cards).where(eq(cards.id, trade.cardId)).limit(1);
        const [listing] = await tx.select().from(listings).where(eq(listings.id, trade.listingId)).limit(1);
        if (!seller || !buyer || !card || !listing || seller.id !== card.currentOwner || listing.status !== "active" || buyer.bitBucks < trade.price) {
          throw new TRPCError({ code: "PRECONDITION_FAILED", message: "The trade can no longer be completed safely." });
        }
        await tx.update(teams).set({ bitBucks: buyer.bitBucks - trade.price }).where(eq(teams.id, buyer.id));
        await tx.update(teams).set({ bitBucks: seller.bitBucks + trade.price }).where(eq(teams.id, seller.id));
        await tx.update(cards).set({ currentOwner: buyer.id, status: "owned" }).where(eq(cards.id, card.id));
        await tx.update(listings).set({ status: "sold" }).where(eq(listings.id, listing.id));
        await tx.update(trades).set({ sellerConfirmed: true, buyerConfirmed: true, status: "completed", completedAt: new Date() }).where(eq(trades.id, trade.id));
        finalStatus = "completed";
      });
      publishGameUpdate();
      return { status: finalStatus };
    }),
    cancelTrade: publicProcedure.input(sessionInput.extend({ tradeId: z.string().min(1) })).mutation(async ({ input }) => {
      const db = await database();
      const teamId = await requireTeam(input.sessionToken);
      const [trade] = await db.select().from(trades).where(eq(trades.id, input.tradeId)).limit(1);
      if (!trade || trade.status !== "pending") throw new TRPCError({ code: "NOT_FOUND", message: "This trade is no longer pending." });
      if (trade.sellerId !== teamId && trade.buyerId !== teamId) throw new TRPCError({ code: "FORBIDDEN", message: "Only a trade participant can cancel it." });
      await db.update(trades).set({ status: "cancelled" }).where(eq(trades.id, trade.id));
      publishGameUpdate();
      return { status: "cancelled" as const };
    }),
    rejectTrade: publicProcedure.input(sessionInput.extend({ tradeId: z.string().min(1) })).mutation(async ({ input }) => {
      const db = await database();
      const teamId = await requireTeam(input.sessionToken);
      const [trade] = await db.select().from(trades).where(eq(trades.id, input.tradeId)).limit(1);
      if (!trade || trade.status !== "pending") throw new TRPCError({ code: "NOT_FOUND", message: "This trade is no longer pending." });
      if (trade.sellerId !== teamId) throw new TRPCError({ code: "FORBIDDEN", message: "Only the seller can reject a purchase request." });
      await db.update(trades).set({ status: "rejected" }).where(eq(trades.id, trade.id));
      publishGameUpdate();
      return { status: "rejected" as const };
    }),
    submitAnswer: publicProcedure.input(sessionInput.extend({ cardId: z.string().min(2).max(16), answer: z.string().trim().min(1).max(200), confidence: z.enum(["low", "medium", "high"]).optional() })).mutation(async ({ input }) => {
      const db = await database();
      const teamId = await requireTeam(input.sessionToken);
      await requirePhase(db, "submit");
      const [card] = await db.select().from(cards).where(eq(cards.id, input.cardId)).limit(1);
      if (!card || card.currentOwner !== teamId) throw new TRPCError({ code: "FORBIDDEN", message: "Only the current owner can submit an answer for this card." });
      const [existing] = await db.select({ id: submissions.id }).from(submissions).where(and(eq(submissions.cardId, input.cardId), eq(submissions.teamId, teamId))).limit(1);
      if (existing) throw new TRPCError({ code: "CONFLICT", message: "This card already has a final submission from your team." });
      await db.insert(submissions).values({ id: `SUB-${nanoid(14)}`, cardId: input.cardId, teamId, answer: input.answer, confidence: input.confidence || "medium", status: "pending" });
      publishGameUpdate();
      return { status: "pending" as const, message: "Your answer is locked and will remain hidden until the reveal." };
    }),
    state: publicProcedure.query(async () => {
      const db = await database();
      const state = await readGameState(db);
      return { phase: state.phase as GamePhase, isActive: state.isActive, updatedAt: state.updatedAt };
    }),
  }),
});

export type AppRouter = typeof appRouter;
