export const GAME_PHASES = ["REGISTRATION", "BAZAAR", "SUBMISSION", "REVEAL", "GAME OVER"] as const;
export type GamePhase = (typeof GAME_PHASES)[number];

export type PlayerAction = "list" | "buy" | "confirmTrade" | "submit";

const phasePermissions: Record<GamePhase, Record<PlayerAction, boolean>> = {
  REGISTRATION: { list: false, buy: false, confirmTrade: false, submit: false },
  BAZAAR: { list: true, buy: true, confirmTrade: true, submit: false },
  SUBMISSION: { list: false, buy: false, confirmTrade: false, submit: true },
  REVEAL: { list: false, buy: false, confirmTrade: false, submit: false },
  "GAME OVER": { list: false, buy: false, confirmTrade: false, submit: false },
};

export function isPlayerActionAllowed(phase: GamePhase, action: PlayerAction) {
  return phasePermissions[phase][action];
}

export function getActionUnavailableMessage(phase: GamePhase, action: PlayerAction) {
  if (isPlayerActionAllowed(phase, action)) return null;
  if (phase === "REGISTRATION") return "The game is in REGISTRATION. Player actions will open when the Bazaar begins.";
  if (phase === "REVEAL") return "The game is in REVEAL. Trading and submissions are locked while answers are revealed.";
  if (phase === "GAME OVER") return "The game is over. The Bazaar and submissions are now read-only.";
  if (action === "submit") return "Answer submission is available only during SUBMISSION.";
  return "Trading is available only during BAZAAR.";
}

export type PlayerCardState = "available" | "listed" | "submitted" | "sold";

export function derivePlayerCardState(cardStatus: "owned" | "listed", hasSubmission: boolean): PlayerCardState {
  if (hasSubmission) return "submitted";
  return cardStatus === "listed" ? "listed" : "available";
}

